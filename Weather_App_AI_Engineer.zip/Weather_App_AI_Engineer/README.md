# 🌍 Weather App AI Engineer — Full-Stack Technical Assessment

> Built for PM Accelerator's AI Engineer Intern technical assessment.

A production-grade **full-stack weather application** featuring JWT authentication, CRUD database persistence, real-time weather/forecast APIs, AI-powered weather assistant, CSV/JSON exports, and a responsive React frontend.

---

## 📌 About PM Accelerator

PM Accelerator's mission is to enable PM professionals to take their career to the next level, and entry-level individuals to break through into Product Management, through hands-on, real-world experience, mentorship, and community-driven learning.

[PM Accelerator on LinkedIn](https://www.linkedin.com/school/pmaccelerator/)

---

## 🎯 Overview

| Component | Details |
|---|---|
| **Backend** | FastAPI + PostgreSQL + Redis + SQLAlchemy |
| **Frontend** | React 18 + Vite + Axios + React Query + Recharts |
| **Auth** | JWT (email/password) |
| **APIs** | Current weather, 5-day forecast, air quality, Google Maps, AI assistant |
| **Database** | Full CRUD for weather query records |
| **Export** | CSV & JSON export endpoints |
| **Tests** | 54 pytest tests, 86% coverage |
| **Docker** | docker-compose with PostgreSQL + Redis |
| **CI/CD** | GitHub Actions (pytest + linting) |

---

## 🏗️ Architecture

```
Weather_App_AI_Engineer/
├── backend/
│   ├── app/
│   │   ├── api/v1/          # API routes (auth, weather, queries, export, assistant)
│   │   ├── core/            # Config, security, logging
│   │   ├── database/        # SQLAlchemy session, Redis client
│   │   ├── models/          # User, WeatherQuery ORM models
│   │   ├── repositories/    # Data access layer
│   │   ├── services/        # Business logic (weather, maps, AI assistant, export)
│   │   ├── schemas/         # Pydantic request/response models
│   │   ├── utils/           # Validators, custom exceptions
│   │   └── main.py          # FastAPI application
│   ├── tests/               # 54 pytest tests (86% coverage)
│   ├── requirements.txt
│   ├── Dockerfile
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── App.jsx
│   │   ├── pages/           # Login, Dashboard
│   │   ├── components/      # Weather, Forecast, History, AQI charts
│   │   ├── api/             # API client (Axios + React Query)
│   │   ├── context/         # Auth context
│   │   └── styles/
│   ├── Dockerfile
│   └── package.json
├── docker-compose.yml       # Full stack: backend, PostgreSQL, Redis
├── .github/workflows/ci.yml # CI/CD pipeline (tests + linting)
└── README.md
```

---

## 🚀 Quick Start

### Prerequisites
- **Docker & Docker Compose** (recommended)
- Or: Python 3.12+, Node.js 18+, PostgreSQL, Redis

### Run with Docker (Recommended)

```bash
# 1. Clone the repository
git clone <your-repo-url>
cd Weather_App_AI_Engineer

# 2. Create a .env file (copy from .env.example and fill in API keys if needed)
cp backend/.env.example backend/.env

# 3. Start all services
docker-compose up

# 4. Access the app
# Frontend: http://localhost:5173
# Backend API: http://localhost:8000
# API Docs: http://localhost:8000/docs
```

### Run Locally (Without Docker)

**Backend:**
```bash
cd backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
# Configure .env with your API keys (optional)
uvicorn app.main:app --reload
# Runs at http://localhost:8000
```

**Frontend:**
```bash
cd frontend
npm install
npm run dev
# Runs at http://localhost:5173
```

---

## ✨ Features

### Authentication
- **Registration** (`POST /api/v1/auth/register`): Create account with email + strong password
- **Login** (`POST /api/v1/auth/login`): Get JWT access token
- **JWT Bearer tokens**: Secure protected endpoints

### Weather Endpoints
- **Current Weather** (`GET /api/v1/weather`): Real-time conditions + details
- **5-Day Forecast** (`GET /api/v1/forecast`): Multi-day predictions
- **Air Quality** (`GET /api/v1/air-quality`): AQI data
- **Location Maps** (`GET /api/v1/location/map`): Google Maps + OpenStreetMap links

### CRUD Weather Queries
- **CREATE** (`POST /api/v1/query`): Save location + date range + auto-fetch temperature summary
- **READ** (`GET /api/v1/queries`): List all queries (paginated), with optional `mine_only` filter
- **READ Single** (`GET /api/v1/query/{id}`): Fetch one record
- **UPDATE** (`PUT /api/v1/query/{id}`): Update notes and date range (with validation)
- **DELETE** (`DELETE /api/v1/query/{id}`): Remove record

### AI Weather Assistant
- **Ask Questions** (`POST /api/v1/assistant/ask`): Natural-language Q&A about weather
  - Examples: "Should I carry an umbrella?", "Is tomorrow good for cricket?", "Best day for outdoor activities?"
  - Uses OpenAI-compatible API (falls back to rule-based if no key configured)
  - Combines live weather context + LLM reasoning

### Data Export
- **CSV Export** (`GET /api/v1/export/csv`): Download all weather queries as CSV
- **JSON Export** (`GET /api/v1/export/json`): Download all weather queries as JSON
- **Streaming responses**: Large datasets handled efficiently

### Frontend UI
- **Login/Register**: Account management
- **Weather Search**: Enter location (city, zip, lat/lon), get current conditions
- **5-Day Forecast**: Visual forecast cards with temp, condition, rain chance, UV
- **Query History**: List, update notes, delete stored queries
- **Charts**: Recharts for temperature trends, forecast visualization
- **AQI Dashboard**: Air quality index breakdown
- **Responsive Design**: Works on desktop, tablet, mobile

---

## 🧪 Testing

**Run the test suite:**
```bash
cd backend
pytest tests/ --cov=app --cov-report=term-missing
```

**Results: 54 tests, 86% coverage**

Test categories:
- Auth registration & login flows
- Weather API endpoints (current, forecast, AQI)
- Full CRUD for weather queries
- Data export (CSV, JSON)
- AI assistant fallback logic
- Validator and security utilities
- Cache client (in-memory fallback when Redis unavailable)

---

## 🔐 Security

- **Password Hashing**: bcrypt via passlib
- **JWT Tokens**: HS256 algorithm, 24-hour expiry by default
- **Input Validation**: Pydantic schemas + custom validators
- **CORS**: Configured for localhost + production origins
- **Error Handling**: Typed exceptions mapped to HTTP responses
- **Logging**: Structured logs at INFO/DEBUG levels

---

## 🌐 Environment Variables

Copy `backend/.env.example` to `backend/.env` and configure:

```bash
# Application
APP_NAME=Weather App AI Engineer
ENVIRONMENT=development
DEBUG=True

# Database (PostgreSQL)
DATABASE_URL=postgresql+psycopg2://weather_user:weather_pass@localhost:5432/weather_db

# Redis
REDIS_URL=redis://localhost:6379/0

# Security
SECRET_KEY=your_super_secret_key_here
ACCESS_TOKEN_EXPIRE_MINUTES=1440

# Weather API (free key from https://www.weatherapi.com/)
WEATHERAPI_KEY=your_api_key_here

# Google Maps (optional; maps gracefully degrade without it)
GOOGLE_MAPS_API_KEY=your_api_key_here

# OpenAI (optional; AI assistant falls back to rules without it)
OPENAI_API_KEY=your_api_key_here
```

---

## 🐳 Docker

**Run all services:**
```bash
docker-compose up
```

**Services:**
- **Backend**: FastAPI + uvicorn (http://localhost:8000)
- **PostgreSQL**: Port 5432
- **Redis**: Port 6379
- **Frontend**: React + Vite (http://localhost:5173)

**Database auto-creation**: Tables are created on first startup via SQLAlchemy `Base.metadata.create_all()`. For production, use Alembic migrations.

---

## 🔄 CI/CD

**GitHub Actions Workflow** (`.github/workflows/ci.yml`):
- **Backend**: pytest + coverage reporting + linting (flake8)
- **Frontend**: npm build + linting
- Triggered on push/PR to main/develop branches

---

## 📊 API Documentation

**Interactive Swagger UI:**
```
http://localhost:8000/docs
```

All endpoints documented with request/response schemas, parameter descriptions, and example values.

---

## 🎬 Demo Video Script

1. **Show the frontend login** (1–2 sec)
2. **Register a test account** (2 sec)
3. **Search for current weather** (London, Paris, etc.) (3 sec)
4. **View 5-day forecast** with charts (2 sec)
5. **Ask the AI assistant** a question ("Should I carry an umbrella?") (2 sec)
6. **Create and store a weather query** (location + date range) (3 sec)
7. **View query history** and update a record (2 sec)
8. **Export as CSV/JSON** (1 sec)
9. **Show backend tests** passing (pytest output) (2 sec)
10. **Show API docs** at /docs (1 sec)

---

## 📷 Screenshots

*(Include screenshots of the frontend login, weather dashboard, forecast, and assistant in your submission)*

---

## 🚀 Future Improvements

- **Multi-step time-series forecasting** (LSTM/Prophet for longer-term trends)
- **Hyperparameter tuning** for model optimization
- **Deployment** to AWS/GCP with CI/CD pipeline
- **Rate limiting** (Redis-backed sliding window)
- **User roles** (admin, analyst, viewer) with row-level security
- **Notification system** (email alerts for extreme weather)
- **Integrations** (Slack, Discord, webhooks)
- **Mobile app** (React Native / Flutter)

---

## 📄 License

MIT License — see [LICENSE](LICENSE)

---

## ✅ Submission Checklist

- [x] Backend: FastAPI + PostgreSQL + Redis
- [x] Frontend: React + Vite
- [x] Auth: JWT registration & login
- [x] CRUD: Full weather query persistence
- [x] APIs: Current weather, forecast, AQI, Google Maps
- [x] AI Assistant: Natural-language Q&A (LLM + rule-based fallback)
- [x] Export: CSV & JSON data export
- [x] Tests: 54 tests, 86% coverage
- [x] Docker: docker-compose for full stack
- [x] CI/CD: GitHub Actions workflow
- [x] Documentation: README, API docs, demo script
- [x] PM Accelerator info: Mission statement in footer + README

---

**Built by [Your Name]**
**PM Accelerator Technical Assessment — AI Engineer Internship**
