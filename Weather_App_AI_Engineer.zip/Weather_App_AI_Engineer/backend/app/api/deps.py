"""
app/api/deps.py
------------------
Shared FastAPI dependencies: database session, current authenticated
user (JWT bearer), and service factory functions. Centralizing these
keeps route modules thin and consistent.
"""

from __future__ import annotations

from fastapi import Depends
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from app.core.security import decode_access_token
from app.database.redis_client import CacheClient, get_cache
from app.database.session import get_db
from app.models.user import User
from app.repositories.user_repository import UserRepository
from app.services.ai_assistant_service import AIAssistantService
from app.services.maps_service import MapsService
from app.services.weather_service import WeatherService
from app.utils.exceptions import AuthenticationError

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login", auto_error=False)


def get_current_user(
    token: str | None = Depends(oauth2_scheme),
    db: Session = Depends(get_db),
) -> User:
    if not token:
        raise AuthenticationError("Not authenticated. Provide a Bearer token.")

    payload = decode_access_token(token)
    if not payload or "sub" not in payload:
        raise AuthenticationError("Invalid or expired token.")

    user = UserRepository(db).get_by_email(payload["sub"])
    if not user:
        raise AuthenticationError("User belonging to this token no longer exists.")
    return user


def get_current_user_optional(
    token: str | None = Depends(oauth2_scheme),
    db: Session = Depends(get_db),
) -> User | None:
    """Like get_current_user, but returns None instead of raising — used by
    endpoints that work for both anonymous and authenticated users (e.g.
    creating a weather query record without requiring login)."""
    if not token:
        return None
    payload = decode_access_token(token)
    if not payload or "sub" not in payload:
        return None
    return UserRepository(db).get_by_email(payload["sub"])


def get_weather_service(cache: CacheClient = Depends(get_cache)) -> WeatherService:
    return WeatherService(cache)


def get_maps_service() -> MapsService:
    return MapsService()


def get_ai_assistant_service(
    weather_service: WeatherService = Depends(get_weather_service),
) -> AIAssistantService:
    return AIAssistantService(weather_service)
