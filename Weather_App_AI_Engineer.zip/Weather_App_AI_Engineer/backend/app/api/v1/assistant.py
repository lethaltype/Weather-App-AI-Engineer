"""
app/api/v1/assistant.py
---------------------------
POST /assistant/ask — the AI Weather Assistant endpoint.
"""

from fastapi import APIRouter, Depends, BackgroundTasks

from app.api.deps import get_ai_assistant_service
from app.core.logging_config import get_logger
from app.schemas.assistant import AssistantRequest, AssistantResponse
from app.services.ai_assistant_service import AIAssistantService

router = APIRouter(prefix="/assistant", tags=["AI Assistant"])
logger = get_logger(__name__)


def _log_assistant_usage(location: str, question: str, model_used: str) -> None:
    """Fire-and-forget background task: audit-log assistant usage without
    blocking the response (demonstrates FastAPI BackgroundTasks usage)."""
    logger.info("AI Assistant used | location=%s | model=%s | question=%r", location, model_used, question)


@router.post("/ask", response_model=AssistantResponse)
def ask_assistant(
    payload: AssistantRequest,
    background_tasks: BackgroundTasks,
    assistant_service: AIAssistantService = Depends(get_ai_assistant_service),
):
    """Ask the AI Weather Assistant a natural-language question about a
    location, e.g. "Should I carry an umbrella?" or "Is tomorrow good for
    cricket?". Combines live weather/forecast context with an
    OpenAI-compatible completion (or a rule-based fallback if no API key
    is configured)."""
    response = assistant_service.answer(payload.location, payload.question)
    background_tasks.add_task(_log_assistant_usage, payload.location, payload.question, response.model_used)
    return response
