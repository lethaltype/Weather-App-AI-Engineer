"""
app/api/v1/export.py
-----------------------
GET /export/csv and GET /export/json — stream all stored weather query
records out as a downloadable file.
"""

from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app.database.session import get_db
from app.repositories.weather_repository import WeatherQueryRepository
from app.services.export_service import export_to_csv, export_to_json

router = APIRouter(prefix="/export", tags=["Export"])


@router.get("/csv")
def export_csv(db: Session = Depends(get_db)):
    items, _ = WeatherQueryRepository(db).list_all(page=1, page_size=10_000)
    csv_content = export_to_csv(items)
    return StreamingResponse(
        iter([csv_content]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=weather_queries.csv"},
    )


@router.get("/json")
def export_json(db: Session = Depends(get_db)):
    items, _ = WeatherQueryRepository(db).list_all(page=1, page_size=10_000)
    json_content = export_to_json(items)
    return StreamingResponse(
        iter([json_content]),
        media_type="application/json",
        headers={"Content-Disposition": "attachment; filename=weather_queries.json"},
    )
