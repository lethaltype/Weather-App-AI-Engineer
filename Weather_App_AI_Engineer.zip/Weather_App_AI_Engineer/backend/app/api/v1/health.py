"""
app/api/v1/health.py
-----------------------
Simple liveness/readiness endpoint, also checking DB and cache connectivity.
"""

from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.core.config import settings
from app.database.redis_client import CacheClient, get_cache
from app.database.session import get_db

router = APIRouter(tags=["Health"])


@router.get("/health")
def health_check(db: Session = Depends(get_db), cache: CacheClient = Depends(get_cache)):
    db_ok = True
    try:
        db.execute(text("SELECT 1"))
    except Exception:
        db_ok = False

    return {
        "status": "ok" if db_ok else "degraded",
        "app": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "environment": settings.ENVIRONMENT,
        "database": "ok" if db_ok else "unreachable",
        "cache": "redis" if not cache.using_fallback else "in_memory_fallback",
    }
