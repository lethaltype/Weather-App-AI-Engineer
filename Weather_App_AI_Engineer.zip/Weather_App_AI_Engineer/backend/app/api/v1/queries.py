"""
app/api/v1/queries.py
-------------------------
Full CRUD for stored weather query records:
    POST   /query        (CREATE)
    GET    /queries       (READ — list, all users, paginated)
    GET    /query/{id}    (READ — single)
    PUT    /query/{id}    (UPDATE)
    DELETE /query/{id}    (DELETE)
"""

from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session

from app.api.deps import get_current_user_optional, get_weather_service
from app.database.session import get_db
from app.models.user import User
from app.repositories.weather_repository import WeatherQueryRepository
from app.schemas.query import PaginatedQueries, WeatherQueryCreate, WeatherQueryOut, WeatherQueryUpdate
from app.services.weather_service import WeatherService
from app.utils.exceptions import NotFoundError
from app.utils.validators import validate_date_range

router = APIRouter(tags=["Weather Queries (CRUD)"])


@router.post("/query", response_model=WeatherQueryOut, status_code=status.HTTP_201_CREATED)
def create_query(
    payload: WeatherQueryCreate,
    db: Session = Depends(get_db),
    current_user: User | None = Depends(get_current_user_optional),
    weather_service: WeatherService = Depends(get_weather_service),
):
    """Create a weather query record: validates the date range and the
    location, fetches a temperature summary for that location/range, and
    persists everything to the database."""
    from app.models.weather_query import WeatherQuery

    validate_date_range(payload.start_date, payload.end_date)
    summary = weather_service.resolve_temperature_summary_for_range(
        payload.location, payload.start_date, payload.end_date
    )

    record = WeatherQuery(
        user_id=current_user.id if current_user else None,
        location_query=payload.location,
        resolved_name=summary["resolved_name"],
        country=summary["country"],
        region=summary["region"],
        latitude=summary["latitude"],
        longitude=summary["longitude"],
        start_date=payload.start_date,
        end_date=payload.end_date,
        avg_temperature_c=summary["avg_temperature_c"],
        min_temperature_c=summary["min_temperature_c"],
        max_temperature_c=summary["max_temperature_c"],
        condition_summary=summary["condition_summary"],
        notes=payload.notes,
    )
    return WeatherQueryRepository(db).create(record)


@router.get("/queries", response_model=PaginatedQueries)
def list_queries(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    mine_only: bool = Query(False, description="If true, only return the current user's queries."),
    db: Session = Depends(get_db),
    current_user: User | None = Depends(get_current_user_optional),
):
    """List stored weather query records. By default returns records from
    ALL users (no row-level security required by the assessment); pass
    `mine_only=true` while authenticated to filter to your own records."""
    repo = WeatherQueryRepository(db)
    if mine_only and current_user:
        items, total = repo.list_by_user(current_user.id, page, page_size)
    else:
        items, total = repo.list_all(page, page_size)
    return PaginatedQueries(total=total, page=page, page_size=page_size, items=items)


@router.get("/query/{query_id}", response_model=WeatherQueryOut)
def get_query(query_id: int, db: Session = Depends(get_db)):
    record = WeatherQueryRepository(db).get_by_id(query_id)
    if not record:
        raise NotFoundError(f"Weather query with id {query_id} was not found.")
    return record


@router.put("/query/{query_id}", response_model=WeatherQueryOut)
def update_query(query_id: int, payload: WeatherQueryUpdate, db: Session = Depends(get_db)):
    repo = WeatherQueryRepository(db)
    record = repo.get_by_id(query_id)
    if not record:
        raise NotFoundError(f"Weather query with id {query_id} was not found.")

    updates = payload.model_dump(exclude_unset=True)
    new_start = updates.get("start_date", record.start_date)
    new_end = updates.get("end_date", record.end_date)
    validate_date_range(new_start, new_end)

    return repo.update(record, updates)


@router.delete("/query/{query_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_query(query_id: int, db: Session = Depends(get_db)):
    repo = WeatherQueryRepository(db)
    record = repo.get_by_id(query_id)
    if not record:
        raise NotFoundError(f"Weather query with id {query_id} was not found.")
    repo.delete(record)
    return None
