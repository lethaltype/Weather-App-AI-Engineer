"""
app/api/v1/router.py
------------------------
Aggregates every v1 route module into a single APIRouter, mounted in
app/main.py under the `/api/v1` prefix.
"""

from fastapi import APIRouter

from app.api.v1 import assistant, auth, export, health, queries, weather

api_router = APIRouter()

api_router.include_router(health.router)
api_router.include_router(auth.router)
api_router.include_router(weather.router)
api_router.include_router(queries.router)
api_router.include_router(export.router)
api_router.include_router(assistant.router)
