"""
app/api/v1/weather.py
-------------------------
GET /weather, GET /forecast, plus air quality and Google Maps location
lookup endpoints.
"""

from fastapi import APIRouter, Depends, Query

from app.api.deps import get_maps_service, get_weather_service
from app.schemas.weather import AirQuality, CurrentWeather, ForecastResponse
from app.services.maps_service import MapsService
from app.services.weather_service import WeatherService

router = APIRouter(tags=["Weather"])


@router.get("/weather", response_model=CurrentWeather)
def get_current_weather(
    location: str = Query(..., description="City, zip/postal code, landmark, or 'lat,lon'"),
    weather_service: WeatherService = Depends(get_weather_service),
):
    """Current weather conditions for a given location."""
    return weather_service.get_current_weather(location)


@router.get("/forecast", response_model=ForecastResponse)
def get_forecast(
    location: str = Query(..., description="City, zip/postal code, landmark, or 'lat,lon'"),
    days: int = Query(5, ge=1, le=10, description="Number of forecast days (default 5)"),
    weather_service: WeatherService = Depends(get_weather_service),
):
    """Multi-day weather forecast (default 5-day) for a given location."""
    return weather_service.get_forecast(location, days=days)


@router.get("/air-quality", response_model=AirQuality)
def get_air_quality(
    location: str = Query(..., description="City, zip/postal code, landmark, or 'lat,lon'"),
    weather_service: WeatherService = Depends(get_weather_service),
):
    """Current air quality index data for a given location."""
    return weather_service.get_air_quality(location)


@router.get("/location/map")
def get_location_map(
    location: str = Query(..., description="City, zip/postal code, landmark, or 'lat,lon'"),
    weather_service: WeatherService = Depends(get_weather_service),
    maps_service: MapsService = Depends(get_maps_service),
):
    """Resolve a location and return Google Maps (or OpenStreetMap fallback) links for it."""
    current = weather_service.get_current_weather(location)
    return maps_service.get_map_links(
        current.location.resolved_name, current.location.latitude, current.location.longitude
    )
