"""Configuration settings for the FastAPI application."""

import os
from functools import lru_cache
from typing import List, Optional
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    # Application
    app_name: str = "Weather App AI Engineer"
    environment: str = os.getenv("ENVIRONMENT", "development")
    debug: bool = os.getenv("DEBUG", "True").lower() == "true"

    # Database
    database_url: str = os.getenv(
        "DATABASE_URL",
        "sqlite:///./weather.db"
    )

    # Redis
    redis_url: str = os.getenv("REDIS_URL", "redis://localhost:6379/0")

    # Security
    secret_key: str = os.getenv("SECRET_KEY", "dev_secret_key_change_in_production")
    algorithm: str = "HS256"
    access_token_expire_minutes: int = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "1440"))

    # External APIs
    weatherapi_key: str = os.getenv("WEATHERAPI_KEY", "")
    weatherapi_base_url: str = "https://api.weatherapi.com/v1"
    google_maps_api_key: str = os.getenv("GOOGLE_MAPS_API_KEY", "")
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    openai_base_url: str = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

    # Pagination
    default_page_size: int = int(os.getenv("DEFAULT_PAGE_SIZE", "20"))
    max_page_size: int = int(os.getenv("MAX_PAGE_SIZE", "100"))

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False

    # Parse CORS origins from comma-separated string
    @property
    def cors_origins(self) -> List[str]:
        """Parse CORS origins from environment variable."""
        cors_env = os.getenv("CORS_ORIGINS", "http://localhost:5173,http://localhost:3000")
        return [origin.strip() for origin in cors_env.split(",") if origin.strip()]


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings()


settings = get_settings()
