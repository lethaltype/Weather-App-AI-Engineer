"""
app/core/logging_config.py
----------------------------
Application-wide logging configuration. Call `configure_logging()` once
at startup (done in app/main.py). Produces structured, timestamped log
lines to stdout, suitable for both local development and container logs.
"""

import logging
import sys

from app.core.config import settings

_LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"


def configure_logging() -> None:
    level = logging.DEBUG if settings.DEBUG else logging.INFO
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter(_LOG_FORMAT))

    root_logger = logging.getLogger()
    root_logger.setLevel(level)
    # Avoid duplicate handlers if configure_logging() is called more than once
    # (e.g. during tests that re-import the app).
    root_logger.handlers = [handler]

    # Quiet down noisy third-party loggers in normal operation.
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING if not settings.DEBUG else logging.INFO)
    logging.getLogger("sqlalchemy.engine").setLevel(logging.INFO if settings.DATABASE_ECHO else logging.WARNING)


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)
