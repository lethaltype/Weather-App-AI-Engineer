"""
app/database/redis_client.py
------------------------------
Redis connection wrapper used for caching weather/forecast responses and
rate-limit-style counters. Falls back transparently to a process-local
in-memory dict if Redis is unreachable (e.g. local dev without Docker, or
the test suite), so the rest of the app never has to special-case its
absence — it just calls `cache.get`/`cache.set` either way.
"""

from __future__ import annotations

import json
import time
from typing import Any, Optional

import redis

from app.core.config import settings
from app.core.logging_config import get_logger

logger = get_logger(__name__)


class _InMemoryFallbackCache:
    """A tiny in-memory cache with TTL support, used when Redis is down."""

    def __init__(self):
        self._store: dict[str, tuple[float, str]] = {}

    def get(self, key: str) -> Optional[str]:
        item = self._store.get(key)
        if not item:
            return None
        expires_at, value = item
        if expires_at < time.time():
            self._store.pop(key, None)
            return None
        return value

    def set(self, key: str, value: str, ex: Optional[int] = None) -> None:
        ttl = ex if ex is not None else settings.CACHE_TTL_SECONDS
        self._store[key] = (time.time() + ttl, value)

    def delete(self, key: str) -> None:
        self._store.pop(key, None)

    def ping(self) -> bool:
        return True


class CacheClient:
    """Thin facade over `redis.Redis` (string get/set + JSON helpers) with
    automatic fallback to an in-memory store if the Redis server is
    unreachable."""

    def __init__(self, redis_url: str):
        self._redis_url = redis_url
        self._fallback = _InMemoryFallbackCache()
        self._client: Optional[redis.Redis] = None
        self._using_fallback = False
        self._connect()

    def _connect(self) -> None:
        try:
            client = redis.Redis.from_url(self._redis_url, decode_responses=True, socket_connect_timeout=1)
            client.ping()
            self._client = client
            self._using_fallback = False
            logger.info("Connected to Redis at %s", self._redis_url)
        except Exception as exc:  # pragma: no cover - depends on environment
            logger.warning("Redis unavailable (%s) — using in-memory cache fallback.", exc)
            self._client = None
            self._using_fallback = True

    @property
    def using_fallback(self) -> bool:
        return self._using_fallback

    def get(self, key: str) -> Optional[str]:
        target = self._fallback if self._using_fallback else self._client
        try:
            return target.get(key)
        except Exception as exc:  # pragma: no cover
            logger.warning("Cache GET failed (%s); switching to fallback.", exc)
            self._using_fallback = True
            return self._fallback.get(key)

    def set(self, key: str, value: str, ex: Optional[int] = None) -> None:
        target = self._fallback if self._using_fallback else self._client
        try:
            target.set(key, value, ex=ex or settings.CACHE_TTL_SECONDS)
        except Exception as exc:  # pragma: no cover
            logger.warning("Cache SET failed (%s); switching to fallback.", exc)
            self._using_fallback = True
            self._fallback.set(key, value, ex=ex)

    def delete(self, key: str) -> None:
        target = self._fallback if self._using_fallback else self._client
        try:
            target.delete(key)
        except Exception:  # pragma: no cover
            self._fallback.delete(key)

    def get_json(self, key: str) -> Optional[Any]:
        raw = self.get(key)
        return json.loads(raw) if raw else None

    def set_json(self, key: str, value: Any, ex: Optional[int] = None) -> None:
        self.set(key, json.dumps(value), ex=ex)


cache_client = CacheClient(settings.REDIS_URL)


def get_cache() -> CacheClient:
    """FastAPI dependency returning the shared cache client instance."""
    return cache_client
