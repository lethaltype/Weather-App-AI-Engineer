"""
app/database/session.py
-------------------------
SQLAlchemy engine, session factory, and declarative Base. Production runs
against PostgreSQL (see `DATABASE_URL`); tests override this with an
in-memory/file-based SQLite engine via dependency overrides (see
`tests/conftest.py`) — no code in this module needs to change between the two.
"""

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker

from app.core.config import settings


class Base(DeclarativeBase):
    """Shared declarative base for all ORM models."""
    pass


def _make_engine():
    connect_args = {}
    if settings.DATABASE_URL.startswith("sqlite"):
        connect_args = {"check_same_thread": False}
    return create_engine(
        settings.DATABASE_URL,
        echo=settings.DATABASE_ECHO,
        pool_pre_ping=True,
        connect_args=connect_args,
    )


engine = _make_engine()
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_db():
    """FastAPI dependency yielding a SQLAlchemy session, always closed after use."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
