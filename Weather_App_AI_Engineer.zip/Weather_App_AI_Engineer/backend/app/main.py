"""
app/main.py
--------------
FastAPI application factory: registers middleware, exception handlers,
and the v1 API router. Run locally with:

    uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
"""

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api.v1.router import api_router
from app.core.config import settings
from app.core.logging_config import configure_logging, get_logger
from app.database.session import Base, engine
from app.utils.exceptions import AppError

configure_logging()
logger = get_logger(__name__)

# Auto-create tables on startup for convenience in dev/demo environments.
# In production, schema changes should go through Alembic migrations
# instead (see alembic/ and the README "Database Migrations" section).
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description=(
        "Production-grade Weather Application API — current weather, 5-day "
        "forecast, air quality, CRUD-backed query history, CSV/JSON export, "
        "JWT authentication, and an AI Weather Assistant."
    ),
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(AppError)
async def app_error_handler(request: Request, exc: AppError):
    logger.warning("AppError on %s %s: %s", request.method, request.url.path, exc.detail)
    return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})


@app.middleware("http")
async def log_requests(request: Request, call_next):
    logger.info("%s %s", request.method, request.url.path)
    response = await call_next(request)
    logger.info("%s %s -> %s", request.method, request.url.path, response.status_code)
    return response


app.include_router(api_router, prefix=settings.API_V1_PREFIX)


@app.get("/", tags=["Root"])
def root():
    return {
        "app": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "docs": "/docs",
        "health": f"{settings.API_V1_PREFIX}/health",
        "about": (
            "Built by [Your Name]. PM Accelerator's mission is to enable PM "
            "professionals to take their career to the next level, and "
            "entry-level individuals to break through into Product "
            "Management, through hands-on, real-world experience, "
            "mentorship, and community-driven learning. "
            "https://www.linkedin.com/school/pmaccelerator/"
        ),
    }
