"""
app/models/weather_query.py
------------------------------
SQLAlchemy ORM model representing a stored weather query record: a
location + date range entered by a user, along with the retrieved
temperature/weather data, supporting full CRUD as required by the
assessment ("CREATE - allow user to enter location and date range and
output temperature for that location within that range; store into DB").
"""

from datetime import date, datetime, timezone

from sqlalchemy import Date, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.session import Base


class WeatherQuery(Base):
    __tablename__ = "weather_queries"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)

    # Location info (resolved via the geocoding/weather provider)
    location_query: Mapped[str] = mapped_column(String(255), nullable=False)
    resolved_name: Mapped[str] = mapped_column(String(255), nullable=True)
    country: Mapped[str] = mapped_column(String(255), nullable=True)
    region: Mapped[str] = mapped_column(String(255), nullable=True)
    latitude: Mapped[float] = mapped_column(Float, nullable=True)
    longitude: Mapped[float] = mapped_column(Float, nullable=True)

    # Requested date range
    start_date: Mapped[date] = mapped_column(Date, nullable=False)
    end_date: Mapped[date] = mapped_column(Date, nullable=False)

    # Retrieved weather summary for the range (denormalized JSON-as-text for simplicity & portability)
    avg_temperature_c: Mapped[float] = mapped_column(Float, nullable=True)
    min_temperature_c: Mapped[float] = mapped_column(Float, nullable=True)
    max_temperature_c: Mapped[float] = mapped_column(Float, nullable=True)
    condition_summary: Mapped[str] = mapped_column(String(255), nullable=True)
    raw_data_json: Mapped[str] = mapped_column(Text, nullable=True)

    notes: Mapped[str] = mapped_column(String(500), nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )

    owner = relationship("User", back_populates="weather_queries")

    def __repr__(self) -> str:  # pragma: no cover
        return f"<WeatherQuery id={self.id} location={self.location_query!r}>"
