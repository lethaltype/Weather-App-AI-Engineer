"""
app/repositories/user_repository.py
---------------------------------------
Data-access layer for the User model. Keeping raw SQLAlchemy queries here
(rather than in services/routes) makes it trivial to swap persistence
implementations or unit-test services with a mocked repository.
"""

from __future__ import annotations

from typing import Optional

from sqlalchemy.orm import Session

from app.models.user import User


class UserRepository:
    def __init__(self, db: Session):
        self.db = db

    def get_by_id(self, user_id: int) -> Optional[User]:
        return self.db.get(User, user_id)

    def get_by_email(self, email: str) -> Optional[User]:
        return self.db.query(User).filter(User.email == email).first()

    def create(self, user: User) -> User:
        self.db.add(user)
        self.db.commit()
        self.db.refresh(user)
        return user
