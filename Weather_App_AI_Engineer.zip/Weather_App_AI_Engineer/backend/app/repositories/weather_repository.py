"""
app/repositories/weather_repository.py
------------------------------------------
Data-access layer for the WeatherQuery model: full CRUD plus pagination
and "all users can read" listing (per the assessment: "Row level security
is not necessary to segment the data by users" for READ).
"""

from __future__ import annotations

from typing import Optional, Sequence

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.weather_query import WeatherQuery


class WeatherQueryRepository:
    def __init__(self, db: Session):
        self.db = db

    def create(self, record: WeatherQuery) -> WeatherQuery:
        self.db.add(record)
        self.db.commit()
        self.db.refresh(record)
        return record

    def get_by_id(self, query_id: int) -> Optional[WeatherQuery]:
        return self.db.get(WeatherQuery, query_id)

    def list_all(self, page: int = 1, page_size: int = 20) -> tuple[Sequence[WeatherQuery], int]:
        """List every stored query (across all users — READ has no row-level
        security per the assessment spec), newest first, paginated."""
        total = self.db.query(WeatherQuery).count()
        offset = (page - 1) * page_size
        items = (
            self.db.execute(
                select(WeatherQuery).order_by(WeatherQuery.created_at.desc()).offset(offset).limit(page_size)
            )
            .scalars()
            .all()
        )
        return items, total

    def list_by_user(self, user_id: int, page: int = 1, page_size: int = 20) -> tuple[Sequence[WeatherQuery], int]:
        base_query = self.db.query(WeatherQuery).filter(WeatherQuery.user_id == user_id)
        total = base_query.count()
        offset = (page - 1) * page_size
        items = (
            base_query.order_by(WeatherQuery.created_at.desc()).offset(offset).limit(page_size).all()
        )
        return items, total

    def update(self, record: WeatherQuery, updates: dict) -> WeatherQuery:
        for field, value in updates.items():
            if value is not None:
                setattr(record, field, value)
        self.db.commit()
        self.db.refresh(record)
        return record

    def delete(self, record: WeatherQuery) -> None:
        self.db.delete(record)
        self.db.commit()
