"""
app/schemas/assistant.py
---------------------------
Pydantic request/response models for the AI Weather Assistant feature.
"""

from typing import Optional

from pydantic import BaseModel, Field


class AssistantRequest(BaseModel):
    location: str = Field(min_length=1, max_length=255, description="City, zip, or 'lat,lon'")
    question: str = Field(
        min_length=3,
        max_length=500,
        description="e.g. 'Should I carry an umbrella?', 'Is tomorrow good for cricket?'",
    )


class AssistantResponse(BaseModel):
    location: str
    question: str
    answer: str
    model_used: str
    used_live_weather_context: bool
    recommendation: Optional[str] = None
