"""
app/schemas/query.py
-----------------------
Pydantic request/response models for the WeatherQuery CRUD resource.
"""

from datetime import date, datetime
from typing import Optional

from pydantic import BaseModel, Field, field_validator


class WeatherQueryCreate(BaseModel):
    location: str = Field(min_length=1, max_length=255, description="City, zip, landmark, or 'lat,lon'")
    start_date: date
    end_date: date
    notes: Optional[str] = Field(default=None, max_length=500)

    @field_validator("end_date")
    @classmethod
    def end_date_after_start(cls, end_date: date, info) -> date:
        start_date = info.data.get("start_date")
        if start_date and end_date < start_date:
            raise ValueError("end_date must be on or after start_date.")
        return end_date


class WeatherQueryUpdate(BaseModel):
    """Only a deliberately limited subset of fields may be updated by a user —
    the resolved geocoding fields and historical weather summary are treated
    as system-of-record data, not user-editable, but notes and the date
    range itself can be corrected."""

    start_date: Optional[date] = None
    end_date: Optional[date] = None
    notes: Optional[str] = Field(default=None, max_length=500)

    @field_validator("end_date")
    @classmethod
    def end_date_after_start(cls, end_date, info):
        start_date = info.data.get("start_date")
        if end_date and start_date and end_date < start_date:
            raise ValueError("end_date must be on or after start_date.")
        return end_date


class WeatherQueryOut(BaseModel):
    id: int
    user_id: Optional[int]
    location_query: str
    resolved_name: Optional[str]
    country: Optional[str]
    region: Optional[str]
    latitude: Optional[float]
    longitude: Optional[float]
    start_date: date
    end_date: date
    avg_temperature_c: Optional[float]
    min_temperature_c: Optional[float]
    max_temperature_c: Optional[float]
    condition_summary: Optional[str]
    notes: Optional[str]
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class PaginatedQueries(BaseModel):
    total: int
    page: int
    page_size: int
    items: list[WeatherQueryOut]
