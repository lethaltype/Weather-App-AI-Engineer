"""
app/schemas/weather.py
-------------------------
Pydantic models for current-weather, 5-day-forecast, and air-quality
API responses.
"""

from typing import List, Optional

from pydantic import BaseModel, Field


class LocationInfo(BaseModel):
    query: str
    resolved_name: str
    country: str
    region: Optional[str] = None
    latitude: float
    longitude: float
    timezone: Optional[str] = None


class CurrentWeather(BaseModel):
    location: LocationInfo
    temperature_c: float
    temperature_f: float
    feels_like_c: float
    condition: str
    icon_url: Optional[str] = None
    humidity: int
    wind_kph: float
    precip_mm: float
    uv_index: float
    last_updated: str


class AirQuality(BaseModel):
    location: LocationInfo
    co: Optional[float] = None
    o3: Optional[float] = None
    no2: Optional[float] = None
    so2: Optional[float] = None
    pm2_5: Optional[float] = None
    pm10: Optional[float] = None
    us_epa_index: Optional[int] = None


class ForecastDay(BaseModel):
    date: str
    max_temp_c: float
    min_temp_c: float
    avg_temp_c: float
    condition: str
    icon_url: Optional[str] = None
    chance_of_rain: int = 0
    uv_index: float = 0.0


class ForecastResponse(BaseModel):
    location: LocationInfo
    forecast_days: List[ForecastDay] = Field(default_factory=list)
