"""
app/services/ai_assistant_service.py
---------------------------------------
The AI Weather Assistant: answers natural-language questions like
"Should I carry an umbrella?", "Is tomorrow good for cricket?", or "Best
day for outdoor activities?" by combining live weather/forecast context
with an OpenAI-compatible chat-completions call.

The HTTP client targets `OPENAI_BASE_URL` + `/chat/completions`, so any
OpenAI-API-compatible provider (OpenAI itself, Azure OpenAI, a local
vLLM/Ollama-compatible gateway, etc.) can be swapped in purely via `.env`.

If no API key is configured, falls back to a deterministic rule-based
answer generator built from the same weather context — so the endpoint
is still fully demoable without any paid API key.
"""

from __future__ import annotations

import httpx

from app.core.config import settings
from app.core.logging_config import get_logger
from app.schemas.assistant import AssistantResponse
from app.schemas.weather import ForecastResponse
from app.services.weather_service import WeatherService

logger = get_logger(__name__)

SYSTEM_PROMPT = (
    "You are a concise, friendly weather assistant embedded in a weather app. "
    "You are given live current-weather and 5-day-forecast data as context. "
    "Answer the user's question directly and practically in 2-4 sentences, "
    "referencing specific numbers from the context (temperature, rain chance, "
    "wind, UV index) where relevant. If the question is about an activity "
    "(sports, travel, errands), give a clear recommendation."
)


class AIAssistantService:
    def __init__(self, weather_service: WeatherService):
        self.weather_service = weather_service
        self.api_key = settings.OPENAI_API_KEY
        self.base_url = settings.OPENAI_BASE_URL
        self.model = settings.OPENAI_MODEL

    # ------------------------------------------------------------------ #
    def _build_context(self, location: str) -> tuple[str, ForecastResponse]:
        current = self.weather_service.get_current_weather(location)
        forecast = self.weather_service.get_forecast(location, days=5)

        lines = [
            f"Location: {current.location.resolved_name}, {current.location.country}",
            f"Current: {current.temperature_c}°C (feels like {current.feels_like_c}°C), "
            f"{current.condition}, humidity {current.humidity}%, wind {current.wind_kph} kph, "
            f"UV index {current.uv_index}, precipitation {current.precip_mm} mm.",
        ]
        for day in forecast.forecast_days:
            lines.append(
                f"{day.date}: {day.condition}, {day.min_temp_c}-{day.max_temp_c}°C "
                f"(avg {day.avg_temp_c}°C), {day.chance_of_rain}% chance of rain, UV {day.uv_index}."
            )
        return "\n".join(lines), forecast

    def _call_llm(self, context: str, question: str) -> str:
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": f"Weather context:\n{context}\n\nQuestion: {question}"},
            ],
            "temperature": 0.4,
            "max_tokens": 220,
        }
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        with httpx.Client(timeout=20.0) as client:
            response = client.post(f"{self.base_url}/chat/completions", json=payload, headers=headers)
        response.raise_for_status()
        data = response.json()
        return data["choices"][0]["message"]["content"].strip()

    # ------------------------------------------------------------------ #
    def _rule_based_fallback(self, context_forecast: ForecastResponse, question: str) -> str:
        """A deterministic, no-API-key-required answer generator, used when
        OPENAI_API_KEY isn't configured. Covers the example questions from
        the assessment (umbrella, outdoor sports, best day) plus a generic
        fallback for anything else."""
        q = question.lower()
        days = context_forecast.forecast_days

        if not days:
            return "I don't have forecast data for that location right now — please try again shortly."

        today = days[0]

        if "umbrella" in q or "rain" in q:
            if today.chance_of_rain >= 50 or "rain" in today.condition.lower():
                return (
                    f"Yes, I'd carry an umbrella today — there's a {today.chance_of_rain}% chance of rain "
                    f"with conditions described as '{today.condition}'."
                )
            return (
                f"You probably won't need an umbrella today — only a {today.chance_of_rain}% chance of rain "
                f"and conditions are '{today.condition}'."
            )

        if "cricket" in q or "outdoor" in q or "sport" in q or "picnic" in q or "hike" in q:
            best_day = min(days, key=lambda d: (d.chance_of_rain, abs(d.avg_temp_c - 24)))
            if best_day.chance_of_rain <= 20 and 15 <= best_day.avg_temp_c <= 32:
                return (
                    f"{best_day.date} looks like the best choice for outdoor activities — "
                    f"'{best_day.condition}', average {best_day.avg_temp_c}°C, only "
                    f"{best_day.chance_of_rain}% chance of rain."
                )
            return (
                f"None of the next {len(days)} days look ideal, but {best_day.date} is the most "
                f"reasonable option: '{best_day.condition}', {best_day.avg_temp_c}°C average, "
                f"{best_day.chance_of_rain}% chance of rain."
            )

        if "best day" in q:
            best_day = min(days, key=lambda d: (d.chance_of_rain, abs(d.avg_temp_c - 24)))
            return (
                f"{best_day.date} looks best overall — '{best_day.condition}', "
                f"{best_day.avg_temp_c}°C average, {best_day.chance_of_rain}% chance of rain, "
                f"UV index {best_day.uv_index}."
            )

        # Generic fallback referencing today's numbers
        return (
            f"Today in your area: '{today.condition}', {today.min_temp_c}-{today.max_temp_c}°C, "
            f"{today.chance_of_rain}% chance of rain, UV index {today.uv_index}. "
            f"(Configure OPENAI_API_KEY for richer, free-form answers to questions like this.)"
        )

    # ------------------------------------------------------------------ #
    def answer(self, location: str, question: str) -> AssistantResponse:
        context_str, forecast = self._build_context(location)

        if self.api_key:
            try:
                answer_text = self._call_llm(context_str, question)
                used_llm = True
            except Exception as exc:  # pragma: no cover - depends on external API availability
                logger.warning("LLM call failed (%s); falling back to rule-based answer.", exc)
                answer_text = self._rule_based_fallback(forecast, question)
                used_llm = False
        else:
            answer_text = self._rule_based_fallback(forecast, question)
            used_llm = False

        return AssistantResponse(
            location=location,
            question=question,
            answer=answer_text,
            model_used=self.model if used_llm else "rule-based-fallback",
            used_live_weather_context=True,
        )
