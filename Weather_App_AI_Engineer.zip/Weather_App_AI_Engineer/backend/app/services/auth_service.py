"""
app/services/auth_service.py
-------------------------------
Registration and login business logic: hashing/verifying passwords,
issuing JWTs, and raising typed errors for conflict/auth failures.
"""

from __future__ import annotations

from sqlalchemy.orm import Session

from app.core.security import create_access_token, hash_password, verify_password
from app.models.user import User
from app.repositories.user_repository import UserRepository
from app.schemas.auth import Token, UserOut, UserRegister
from app.utils.exceptions import AuthenticationError, ConflictError


class AuthService:
    def __init__(self, db: Session):
        self.db = db
        self.repo = UserRepository(db)

    def register(self, payload: UserRegister) -> Token:
        existing = self.repo.get_by_email(payload.email)
        if existing:
            raise ConflictError(f"A user with email '{payload.email}' already exists.")

        user = User(
            email=payload.email,
            full_name=payload.full_name,
            hashed_password=hash_password(payload.password),
        )
        user = self.repo.create(user)

        token = create_access_token(subject=user.email)
        return Token(access_token=token, user=UserOut.model_validate(user))

    def login(self, email: str, password: str) -> Token:
        user = self.repo.get_by_email(email)
        if not user or not verify_password(password, user.hashed_password):
            raise AuthenticationError("Incorrect email or password.")
        if not user.is_active:
            raise AuthenticationError("This account has been deactivated.")

        token = create_access_token(subject=user.email)
        return Token(access_token=token, user=UserOut.model_validate(user))
