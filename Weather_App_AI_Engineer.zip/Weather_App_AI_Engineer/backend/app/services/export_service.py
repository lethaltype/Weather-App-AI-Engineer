"""
app/services/export_service.py
----------------------------------
Exports a list of WeatherQuery records to CSV or JSON. Used by the
`/export/csv` and `/export/json` endpoints (StreamingResponse).
"""

from __future__ import annotations

import csv
import io
import json
from datetime import date, datetime
from typing import Iterable

from app.models.weather_query import WeatherQuery

EXPORT_FIELDS = [
    "id",
    "user_id",
    "location_query",
    "resolved_name",
    "country",
    "region",
    "latitude",
    "longitude",
    "start_date",
    "end_date",
    "avg_temperature_c",
    "min_temperature_c",
    "max_temperature_c",
    "condition_summary",
    "notes",
    "created_at",
    "updated_at",
]


def _serialize_value(value):
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    return value


def _record_to_dict(record: WeatherQuery) -> dict:
    return {field: _serialize_value(getattr(record, field)) for field in EXPORT_FIELDS}


def export_to_csv(records: Iterable[WeatherQuery]) -> str:
    """Serialize weather query records to a CSV string."""
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=EXPORT_FIELDS)
    writer.writeheader()
    for record in records:
        writer.writerow(_record_to_dict(record))
    return buffer.getvalue()


def export_to_json(records: Iterable[WeatherQuery]) -> str:
    """Serialize weather query records to a pretty-printed JSON string."""
    data = [_record_to_dict(record) for record in records]
    return json.dumps(data, indent=2, default=str)
