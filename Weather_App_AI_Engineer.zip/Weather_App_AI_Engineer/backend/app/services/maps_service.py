"""
app/services/maps_service.py
-------------------------------
Google Maps integration: returns a static-map URL and a Maps "place" deep
link for a given location, plus a Geocoding API lookup when coordinates
are needed. Degrades gracefully (returns a plain OpenStreetMap link
instead) if no `GOOGLE_MAPS_API_KEY` is configured, so the rest of the
app still functions in a free/local dev setup.
"""

from __future__ import annotations

from typing import Optional

import httpx

from app.core.config import settings
from app.core.logging_config import get_logger

logger = get_logger(__name__)


class MapsService:
    GEOCODE_URL = "https://maps.googleapis.com/maps/api/geocode/json"
    STATICMAP_URL = "https://maps.googleapis.com/maps/api/staticmap"

    def __init__(self):
        self.api_key = settings.GOOGLE_MAPS_API_KEY

    def get_map_links(self, location_name: str, latitude: float, longitude: float) -> dict:
        """Return a dict of map-related links/URLs for a resolved location."""
        if self.api_key:
            static_map_url = (
                f"{self.STATICMAP_URL}?center={latitude},{longitude}&zoom=10&size=600x350"
                f"&markers=color:red%7C{latitude},{longitude}&key={self.api_key}"
            )
            embed_url = (
                f"https://www.google.com/maps/embed/v1/place?key={self.api_key}"
                f"&q={latitude},{longitude}"
            )
        else:
            static_map_url = None
            embed_url = None

        return {
            "provider": "google_maps" if self.api_key else "openstreetmap_fallback",
            "static_map_url": static_map_url,
            "embed_url": embed_url,
            "view_url": f"https://www.google.com/maps/search/?api=1&query={latitude},{longitude}",
            "fallback_view_url": f"https://www.openstreetmap.org/?mlat={latitude}&mlon={longitude}#map=10/{latitude}/{longitude}",
        }

    def geocode(self, address: str) -> Optional[dict]:
        """Resolve a free-text address to lat/lon using the Google Geocoding
        API. Returns None (and logs a warning) if no API key is configured
        or the lookup fails — callers should fall back to the weather
        provider's own geocoding in that case."""
        if not self.api_key:
            logger.info("GOOGLE_MAPS_API_KEY not set; skipping Google geocoding for '%s'.", address)
            return None

        try:
            with httpx.Client(timeout=10.0) as client:
                response = client.get(self.GEOCODE_URL, params={"address": address, "key": self.api_key})
            data = response.json()
            if data.get("status") != "OK" or not data.get("results"):
                return None
            result = data["results"][0]
            location = result["geometry"]["location"]
            return {
                "formatted_address": result["formatted_address"],
                "latitude": location["lat"],
                "longitude": location["lng"],
            }
        except Exception as exc:  # pragma: no cover
            logger.warning("Google geocoding failed for '%s': %s", address, exc)
            return None
