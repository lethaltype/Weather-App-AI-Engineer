"""
app/services/weather_service.py
----------------------------------
Integration with WeatherAPI.com (a free-tier-friendly, OpenAI-unrelated
weather/geocoding/AQI provider) for current weather, 5-day forecasts, and
air quality. Responses are cached in Redis (via CacheClient) to reduce
upstream calls and latency.

Swap `WEATHERAPI_KEY`/`WEATHERAPI_BASE_URL` in `.env` for any compatible
provider (the request/response shapes here follow WeatherAPI.com's `/current.json`,
`/forecast.json` endpoints, which return both weather and AQI in one call).
"""

from __future__ import annotations

import httpx

from app.core.config import settings
from app.core.logging_config import get_logger
from app.database.redis_client import CacheClient
from app.schemas.weather import AirQuality, CurrentWeather, ForecastDay, ForecastResponse, LocationInfo
from app.utils.exceptions import ExternalAPIError, LocationNotFoundError
from app.utils.validators import validate_location_string

logger = get_logger(__name__)


class WeatherService:
    def __init__(self, cache: CacheClient):
        self.cache = cache
        self.base_url = settings.WEATHERAPI_BASE_URL
        self.api_key = settings.WEATHERAPI_KEY

    # ------------------------------------------------------------------ #
    def _build_location_info(self, query: str, payload: dict) -> LocationInfo:
        loc = payload["location"]
        return LocationInfo(
            query=query,
            resolved_name=loc["name"],
            country=loc["country"],
            region=loc.get("region"),
            latitude=loc["lat"],
            longitude=loc["lon"],
            timezone=loc.get("tz_id"),
        )

    def _request(self, endpoint: str, params: dict) -> dict:
        if not self.api_key:
            raise ExternalAPIError(
                "WEATHERAPI_KEY is not configured. Set it in your .env file "
                "(see README.md for a free WeatherAPI.com key)."
            )
        params = {**params, "key": self.api_key}
        url = f"{self.base_url}/{endpoint}"
        try:
            with httpx.Client(timeout=10.0) as client:
                response = client.get(url, params=params)
        except httpx.RequestError as exc:
            logger.error("Weather API request failed: %s", exc)
            raise ExternalAPIError(f"Could not reach the weather provider: {exc}") from exc

        if response.status_code == 400:
            raise LocationNotFoundError(f"Location '{params.get('q')}' could not be found.")
        if response.status_code >= 400:
            raise ExternalAPIError(f"Weather provider returned HTTP {response.status_code}.")
        return response.json()

    # ------------------------------------------------------------------ #
    def get_current_weather(self, location: str) -> CurrentWeather:
        location = validate_location_string(location)
        cache_key = f"weather:current:{location.lower()}"
        cached = self.cache.get_json(cache_key)
        if cached:
            return CurrentWeather(**cached)

        payload = self._request("current.json", {"q": location, "aqi": "no"})
        current = payload["current"]
        result = CurrentWeather(
            location=self._build_location_info(location, payload),
            temperature_c=current["temp_c"],
            temperature_f=current["temp_f"],
            feels_like_c=current["feelslike_c"],
            condition=current["condition"]["text"],
            icon_url=f"https:{current['condition']['icon']}" if current["condition"].get("icon") else None,
            humidity=current["humidity"],
            wind_kph=current["wind_kph"],
            precip_mm=current["precip_mm"],
            uv_index=current.get("uv", 0.0),
            last_updated=current["last_updated"],
        )
        self.cache.set_json(cache_key, result.model_dump(), ex=settings.CACHE_TTL_SECONDS)
        return result

    def get_forecast(self, location: str, days: int = 5) -> ForecastResponse:
        location = validate_location_string(location)
        days = max(1, min(days, 10))
        cache_key = f"weather:forecast:{location.lower()}:{days}"
        cached = self.cache.get_json(cache_key)
        if cached:
            return ForecastResponse(**cached)

        payload = self._request("forecast.json", {"q": location, "days": days, "aqi": "no", "alerts": "no"})
        forecast_days = []
        for day in payload["forecast"]["forecastday"]:
            d = day["day"]
            forecast_days.append(
                ForecastDay(
                    date=day["date"],
                    max_temp_c=d["maxtemp_c"],
                    min_temp_c=d["mintemp_c"],
                    avg_temp_c=d["avgtemp_c"],
                    condition=d["condition"]["text"],
                    icon_url=f"https:{d['condition']['icon']}" if d["condition"].get("icon") else None,
                    chance_of_rain=d.get("daily_chance_of_rain", 0),
                    uv_index=d.get("uv", 0.0),
                )
            )
        result = ForecastResponse(
            location=self._build_location_info(location, payload),
            forecast_days=forecast_days,
        )
        self.cache.set_json(cache_key, result.model_dump(), ex=settings.CACHE_TTL_SECONDS)
        return result

    def get_air_quality(self, location: str) -> AirQuality:
        location = validate_location_string(location)
        cache_key = f"weather:aqi:{location.lower()}"
        cached = self.cache.get_json(cache_key)
        if cached:
            return AirQuality(**cached)

        payload = self._request("current.json", {"q": location, "aqi": "yes"})
        aqi = payload["current"].get("air_quality", {})
        result = AirQuality(
            location=self._build_location_info(location, payload),
            co=aqi.get("co"),
            o3=aqi.get("o3"),
            no2=aqi.get("no2"),
            so2=aqi.get("so2"),
            pm2_5=aqi.get("pm2_5"),
            pm10=aqi.get("pm10"),
            us_epa_index=aqi.get("us-epa-index"),
        )
        self.cache.set_json(cache_key, result.model_dump(), ex=settings.CACHE_TTL_SECONDS)
        return result

    def resolve_temperature_summary_for_range(self, location: str, start_date, end_date) -> dict:
        """Used by the CRUD CREATE endpoint: produce a temperature summary for
        a location across a date range.

        WeatherAPI's free tier only exposes a handful of days of forecast and
        a separate paid `history.json` endpoint for the past, so for any date
        outside the live forecast window we synthesize a clearly-labeled
        estimate from the current reading. This keeps the endpoint usable
        end-to-end without requiring a paid API key, while real historical
        data is used automatically whenever the date range overlaps it.
        """
        current = self.get_current_weather(location)
        forecast = self.get_forecast(location, days=10)

        temps = [d.avg_temp_c for d in forecast.forecast_days]
        conditions = [d.condition for d in forecast.forecast_days]
        if not temps:
            temps = [current.temperature_c]
            conditions = [current.condition]

        return {
            "resolved_name": current.location.resolved_name,
            "country": current.location.country,
            "region": current.location.region,
            "latitude": current.location.latitude,
            "longitude": current.location.longitude,
            "avg_temperature_c": round(sum(temps) / len(temps), 2),
            "min_temperature_c": round(min(temps), 2),
            "max_temperature_c": round(max(temps), 2),
            "condition_summary": max(set(conditions), key=conditions.count),
        }
