"""
app/utils/exceptions.py
--------------------------
Custom application exceptions, mapped to HTTP responses by handlers
registered in app/main.py. Using typed exceptions (instead of raising
HTTPException everywhere) keeps the service/repository layers free of
any FastAPI/HTTP-specific imports.
"""


class AppError(Exception):
    """Base class for all application-level errors."""

    status_code: int = 500
    detail: str = "An unexpected error occurred."

    def __init__(self, detail: str | None = None):
        self.detail = detail or self.detail
        super().__init__(self.detail)


class NotFoundError(AppError):
    status_code = 404
    detail = "The requested resource was not found."


class ValidationError(AppError):
    status_code = 422
    detail = "Invalid input."


class AuthenticationError(AppError):
    status_code = 401
    detail = "Invalid authentication credentials."


class AuthorizationError(AppError):
    status_code = 403
    detail = "You do not have permission to perform this action."


class ConflictError(AppError):
    status_code = 409
    detail = "The resource already exists."


class ExternalAPIError(AppError):
    status_code = 502
    detail = "An upstream service failed to respond correctly."


class LocationNotFoundError(NotFoundError):
    detail = "Could not resolve the given location."
