"""
app/utils/validators.py
--------------------------
Small, dependency-free validation helpers reused across services/schemas:
date-range validation and lightweight location-string sanity checks.
"""

from datetime import date, timedelta

from app.utils.exceptions import ValidationError

MAX_DATE_RANGE_DAYS = 366


def validate_date_range(start_date: date, end_date: date) -> None:
    """Raise ValidationError if the date range is incoherent or excessive."""
    if end_date < start_date:
        raise ValidationError("end_date must be on or after start_date.")
    if (end_date - start_date) > timedelta(days=MAX_DATE_RANGE_DAYS):
        raise ValidationError(f"Date range cannot exceed {MAX_DATE_RANGE_DAYS} days.")


def validate_location_string(location: str) -> str:
    """Basic sanity-check + normalization of a user-supplied location string
    (city name, zip/postal code, 'lat,lon' pair, or landmark)."""
    location = (location or "").strip()
    if not location:
        raise ValidationError("Location must not be empty.")
    if len(location) > 255:
        raise ValidationError("Location string is too long.")
    return location


def is_lat_lon_pair(location: str) -> bool:
    """Detect whether a location string looks like a 'lat,lon' coordinate pair."""
    parts = location.split(",")
    if len(parts) != 2:
        return False
    try:
        lat, lon = float(parts[0].strip()), float(parts[1].strip())
    except ValueError:
        return False
    return -90 <= lat <= 90 and -180 <= lon <= 180
