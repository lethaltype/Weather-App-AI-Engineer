#!/bin/bash
# Initialize database before starting the application

# Wait for PostgreSQL to be ready
echo "Waiting for PostgreSQL to be ready..."
for i in {1..30}; do
  if PGPASSWORD=weather_pass psql -h postgres -U weather_user -d postgres -c "SELECT 1" 2>/dev/null; then
    echo "PostgreSQL is ready!"
    break
  fi
  echo "Attempt $i: PostgreSQL not ready yet, waiting..."
  sleep 2
done

# Create database if it doesn't exist
echo "Creating database if it doesn't exist..."
PGPASSWORD=weather_pass psql -h postgres -U weather_user -d postgres -c "CREATE DATABASE weather_db;" 2>/dev/null || echo "Database already exists or error occurred"

echo "Database initialization complete!"
exec "$@"
