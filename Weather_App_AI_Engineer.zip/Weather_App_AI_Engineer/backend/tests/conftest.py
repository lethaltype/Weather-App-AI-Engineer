"""
tests/conftest.py
--------------------
Shared pytest fixtures:
    * `db_session`   — a fresh in-memory SQLite database per test.
    * `client`        — a FastAPI TestClient with `get_db` and the weather
                         service overridden so tests never hit a real
                         Postgres, Redis, or external weather API.
    * `auth_headers`  — registers a user and returns ready-to-use Bearer headers.

Using SQLite for tests (instead of requiring a live PostgreSQL instance)
is a standard, widely-used FastAPI testing pattern — the application code
itself is fully database-agnostic via SQLAlchemy, so this doesn't test
anything PostgreSQL-specific differently than SQLite would.
"""

from __future__ import annotations

from datetime import date, timedelta

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.api.deps import get_ai_assistant_service, get_maps_service, get_weather_service
from app.database.session import Base, get_db
from app.main import app
from app.schemas.assistant import AssistantResponse
from app.schemas.weather import AirQuality, CurrentWeather, ForecastDay, ForecastResponse, LocationInfo

TEST_DATABASE_URL = "sqlite:///:memory:"


@pytest.fixture()
def db_session():
    engine = create_engine(
        TEST_DATABASE_URL,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    Base.metadata.create_all(bind=engine)

    session = TestingSessionLocal()
    try:
        yield session
    finally:
        session.close()
        Base.metadata.drop_all(bind=engine)
        engine.dispose()


class FakeWeatherService:
    """A stand-in for WeatherService that returns deterministic fixture data
    instead of calling a real external API — keeps tests fast, free, and
    network-independent."""

    def _location_info(self, location: str) -> LocationInfo:
        return LocationInfo(
            query=location,
            resolved_name="Testville",
            country="Testland",
            region="Test Region",
            latitude=12.34,
            longitude=56.78,
            timezone="UTC",
        )

    def get_current_weather(self, location: str) -> CurrentWeather:
        return CurrentWeather(
            location=self._location_info(location),
            temperature_c=25.0,
            temperature_f=77.0,
            feels_like_c=26.0,
            condition="Sunny",
            icon_url="https://example.com/sunny.png",
            humidity=50,
            wind_kph=10.0,
            precip_mm=0.0,
            uv_index=6.0,
            last_updated="2025-01-01 12:00",
        )

    def get_forecast(self, location: str, days: int = 5) -> ForecastResponse:
        today = date.today()
        forecast_days = [
            ForecastDay(
                date=str(today + timedelta(days=i)),
                max_temp_c=28.0 + i,
                min_temp_c=18.0 + i,
                avg_temp_c=23.0 + i,
                condition="Sunny" if i % 2 == 0 else "Light rain",
                icon_url="https://example.com/icon.png",
                chance_of_rain=10 if i % 2 == 0 else 70,
                uv_index=6.0,
            )
            for i in range(days)
        ]
        return ForecastResponse(location=self._location_info(location), forecast_days=forecast_days)

    def get_air_quality(self, location: str) -> AirQuality:
        return AirQuality(
            location=self._location_info(location),
            co=200.0,
            o3=50.0,
            no2=10.0,
            so2=5.0,
            pm2_5=15.0,
            pm10=25.0,
            us_epa_index=2,
        )

    def resolve_temperature_summary_for_range(self, location: str, start_date, end_date) -> dict:
        loc = self._location_info(location)
        return {
            "resolved_name": loc.resolved_name,
            "country": loc.country,
            "region": loc.region,
            "latitude": loc.latitude,
            "longitude": loc.longitude,
            "avg_temperature_c": 24.5,
            "min_temperature_c": 18.0,
            "max_temperature_c": 30.0,
            "condition_summary": "Sunny",
        }


class FakeMapsService:
    def get_map_links(self, location_name, latitude, longitude):
        return {
            "provider": "openstreetmap_fallback",
            "static_map_url": None,
            "embed_url": None,
            "view_url": f"https://www.google.com/maps/search/?api=1&query={latitude},{longitude}",
            "fallback_view_url": f"https://www.openstreetmap.org/?mlat={latitude}&mlon={longitude}",
        }


class FakeAIAssistantService:
    def answer(self, location: str, question: str) -> AssistantResponse:
        return AssistantResponse(
            location=location,
            question=question,
            answer=f"(test) Based on the forecast for {location}, here's my answer to: {question}",
            model_used="rule-based-fallback",
            used_live_weather_context=True,
        )


@pytest.fixture()
def client(db_session):
    def override_get_db():
        try:
            yield db_session
        finally:
            pass

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_weather_service] = lambda: FakeWeatherService()
    app.dependency_overrides[get_maps_service] = lambda: FakeMapsService()
    app.dependency_overrides[get_ai_assistant_service] = lambda: FakeAIAssistantService()

    with TestClient(app) as test_client:
        yield test_client

    app.dependency_overrides.clear()


@pytest.fixture()
def auth_headers(client):
    """Registers a fresh user and returns {'Authorization': 'Bearer ...'} headers."""
    response = client.post(
        "/api/v1/auth/register",
        json={"email": "tester@example.com", "password": "Sup3rSecret", "full_name": "Test User"},
    )
    assert response.status_code == 201, response.text
    token = response.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}
