"""tests/test_assistant_and_health.py — AI assistant endpoint + health check."""


def test_health_check_returns_ok(client):
    response = client.get("/api/v1/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"
    assert "database" in data
    assert "cache" in data


def test_assistant_umbrella_question(client):
    response = client.post(
        "/api/v1/assistant/ask",
        json={"location": "Seattle", "question": "Should I carry an umbrella?"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["location"] == "Seattle"
    assert data["used_live_weather_context"] is True
    assert len(data["answer"]) > 0


def test_assistant_cricket_question(client):
    response = client.post(
        "/api/v1/assistant/ask",
        json={"location": "Mumbai", "question": "Is tomorrow good for cricket?"},
    )
    assert response.status_code == 200
    assert "Mumbai" in response.json()["answer"] or len(response.json()["answer"]) > 0


def test_assistant_question_too_short_returns_422(client):
    response = client.post("/api/v1/assistant/ask", json={"location": "Rome", "question": "?"})
    assert response.status_code == 422


def test_root_endpoint_includes_pm_accelerator_info(client):
    response = client.get("/")
    assert response.status_code == 200
    assert "PM Accelerator" in response.json()["about"]
