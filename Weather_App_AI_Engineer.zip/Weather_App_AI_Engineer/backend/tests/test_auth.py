"""tests/test_auth.py — registration & login flow tests."""


def test_register_creates_user_and_returns_token(client):
    response = client.post(
        "/api/v1/auth/register",
        json={"email": "alice@example.com", "password": "Passw0rd1", "full_name": "Alice"},
    )
    assert response.status_code == 201
    data = response.json()
    assert data["user"]["email"] == "alice@example.com"
    assert data["token_type"] == "bearer"
    assert data["access_token"]


def test_register_duplicate_email_returns_409(client):
    payload = {"email": "bob@example.com", "password": "Passw0rd1"}
    first = client.post("/api/v1/auth/register", json=payload)
    assert first.status_code == 201

    second = client.post("/api/v1/auth/register", json=payload)
    assert second.status_code == 409


def test_register_weak_password_rejected(client):
    response = client.post(
        "/api/v1/auth/register", json={"email": "weak@example.com", "password": "alllowercase"}
    )
    assert response.status_code == 422


def test_login_with_correct_credentials_succeeds(client):
    client.post("/api/v1/auth/register", json={"email": "carl@example.com", "password": "Passw0rd1"})
    response = client.post("/api/v1/auth/login", json={"email": "carl@example.com", "password": "Passw0rd1"})
    assert response.status_code == 200
    assert response.json()["user"]["email"] == "carl@example.com"


def test_login_with_wrong_password_returns_401(client):
    client.post("/api/v1/auth/register", json={"email": "dana@example.com", "password": "Passw0rd1"})
    response = client.post("/api/v1/auth/login", json={"email": "dana@example.com", "password": "WrongPass1"})
    assert response.status_code == 401


def test_login_with_unknown_email_returns_401(client):
    response = client.post("/api/v1/auth/login", json={"email": "nobody@example.com", "password": "Passw0rd1"})
    assert response.status_code == 401
