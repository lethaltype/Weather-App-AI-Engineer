"""tests/test_export.py — CSV and JSON export endpoint tests."""

import csv
import io
import json
from datetime import date, timedelta


def _create_record(client, location="ExportCity"):
    today = date.today()
    return client.post(
        "/api/v1/query",
        json={
            "location": location,
            "start_date": str(today),
            "end_date": str(today + timedelta(days=2)),
        },
    )


def test_export_csv_contains_created_record(client):
    _create_record(client, "ExportCityCSV")
    response = client.get("/api/v1/export/csv")
    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/csv")

    reader = csv.DictReader(io.StringIO(response.text))
    rows = list(reader)
    assert any(row["location_query"] == "ExportCityCSV" for row in rows)


def test_export_json_contains_created_record(client):
    _create_record(client, "ExportCityJSON")
    response = client.get("/api/v1/export/json")
    assert response.status_code == 200
    assert response.headers["content-type"].startswith("application/json")

    data = json.loads(response.text)
    assert any(row["location_query"] == "ExportCityJSON" for row in data)


def test_export_csv_empty_when_no_records(client):
    response = client.get("/api/v1/export/csv")
    assert response.status_code == 200
    reader = csv.DictReader(io.StringIO(response.text))
    assert list(reader) == []
