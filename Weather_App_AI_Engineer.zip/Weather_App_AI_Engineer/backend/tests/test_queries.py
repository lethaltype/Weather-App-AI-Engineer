"""tests/test_queries.py — full CRUD coverage for the weather query resource."""

from datetime import date, timedelta


def _create_payload(**overrides):
    today = date.today()
    payload = {
        "location": "New York",
        "start_date": str(today),
        "end_date": str(today + timedelta(days=3)),
        "notes": "Trip planning",
    }
    payload.update(overrides)
    return payload


def test_create_query_anonymous(client):
    response = client.post("/api/v1/query", json=_create_payload())
    assert response.status_code == 201
    data = response.json()
    assert data["location_query"] == "New York"
    assert data["resolved_name"] == "Testville"
    assert data["user_id"] is None
    assert data["avg_temperature_c"] == 24.5


def test_create_query_authenticated_attaches_user(client, auth_headers):
    response = client.post("/api/v1/query", json=_create_payload(), headers=auth_headers)
    assert response.status_code == 201
    assert response.json()["user_id"] is not None


def test_create_query_invalid_date_range_returns_422(client):
    today = date.today()
    payload = _create_payload(start_date=str(today), end_date=str(today - timedelta(days=1)))
    response = client.post("/api/v1/query", json=payload)
    assert response.status_code == 422


def test_list_queries_returns_created_records(client):
    client.post("/api/v1/query", json=_create_payload(location="Tokyo"))
    client.post("/api/v1/query", json=_create_payload(location="Paris"))

    response = client.get("/api/v1/queries")
    assert response.status_code == 200
    data = response.json()
    assert data["total"] == 2
    assert len(data["items"]) == 2


def test_list_queries_pagination(client):
    for i in range(5):
        client.post("/api/v1/query", json=_create_payload(location=f"City{i}"))

    response = client.get("/api/v1/queries", params={"page": 1, "page_size": 2})
    data = response.json()
    assert data["total"] == 5
    assert len(data["items"]) == 2


def test_get_single_query(client):
    created = client.post("/api/v1/query", json=_create_payload()).json()
    response = client.get(f"/api/v1/query/{created['id']}")
    assert response.status_code == 200
    assert response.json()["id"] == created["id"]


def test_get_nonexistent_query_returns_404(client):
    response = client.get("/api/v1/query/99999")
    assert response.status_code == 404


def test_update_query_notes(client):
    created = client.post("/api/v1/query", json=_create_payload()).json()
    response = client.put(f"/api/v1/query/{created['id']}", json={"notes": "Updated note"})
    assert response.status_code == 200
    assert response.json()["notes"] == "Updated note"


def test_update_query_invalid_range_returns_422(client):
    created = client.post("/api/v1/query", json=_create_payload()).json()
    today = date.today()
    response = client.put(
        f"/api/v1/query/{created['id']}",
        json={"start_date": str(today + timedelta(days=10)), "end_date": str(today)},
    )
    assert response.status_code == 422


def test_update_nonexistent_query_returns_404(client):
    response = client.put("/api/v1/query/99999", json={"notes": "x"})
    assert response.status_code == 404


def test_delete_query(client):
    created = client.post("/api/v1/query", json=_create_payload()).json()
    response = client.delete(f"/api/v1/query/{created['id']}")
    assert response.status_code == 204

    follow_up = client.get(f"/api/v1/query/{created['id']}")
    assert follow_up.status_code == 404


def test_delete_nonexistent_query_returns_404(client):
    response = client.delete("/api/v1/query/99999")
    assert response.status_code == 404


def test_mine_only_filter_requires_auth_context(client, auth_headers):
    client.post("/api/v1/query", json=_create_payload(location="Mine"), headers=auth_headers)
    client.post("/api/v1/query", json=_create_payload(location="NotMine"))

    response = client.get("/api/v1/queries", params={"mine_only": True}, headers=auth_headers)
    data = response.json()
    assert data["total"] == 1
    assert data["items"][0]["location_query"] == "Mine"
