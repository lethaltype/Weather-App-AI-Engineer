"""
tests/test_services_unit.py
------------------------------
Direct unit tests for the service/utility layer, exercising code paths
not reached through the API-level tests (e.g. WeatherService HTTP calls
mocked via monkeypatching, the AI assistant's rule-based fallback, the
Maps service without an API key, and validator/security edge cases).
"""

from datetime import date, timedelta

import pytest

from app.core.security import create_access_token, decode_access_token, hash_password, verify_password
from app.database.redis_client import CacheClient
from app.services.ai_assistant_service import AIAssistantService
from app.services.maps_service import MapsService
from app.services.weather_service import WeatherService
from app.utils.exceptions import ExternalAPIError, LocationNotFoundError, ValidationError
from app.utils.validators import is_lat_lon_pair, validate_date_range, validate_location_string


# --------------------------------------------------------------------------- #
# security.py
# --------------------------------------------------------------------------- #
def test_password_hash_and_verify_roundtrip():
    hashed = hash_password("MySecret123")
    assert hashed != "MySecret123"
    assert verify_password("MySecret123", hashed)
    assert not verify_password("WrongPassword1", hashed)


def test_access_token_roundtrip():
    token = create_access_token("user@example.com")
    payload = decode_access_token(token)
    assert payload["sub"] == "user@example.com"


def test_decode_invalid_token_returns_none():
    assert decode_access_token("not-a-real-jwt-token") is None


# --------------------------------------------------------------------------- #
# validators.py
# --------------------------------------------------------------------------- #
def test_validate_date_range_rejects_end_before_start():
    with pytest.raises(ValidationError):
        validate_date_range(date.today(), date.today() - timedelta(days=1))


def test_validate_date_range_rejects_excessive_span():
    with pytest.raises(ValidationError):
        validate_date_range(date.today(), date.today() + timedelta(days=400))


def test_validate_date_range_accepts_valid_range():
    validate_date_range(date.today(), date.today() + timedelta(days=5))  # should not raise


def test_validate_location_string_rejects_empty():
    with pytest.raises(ValidationError):
        validate_location_string("   ")


def test_validate_location_string_strips_whitespace():
    assert validate_location_string("  London  ") == "London"


def test_is_lat_lon_pair_true_and_false():
    assert is_lat_lon_pair("12.34,56.78") is True
    assert is_lat_lon_pair("London") is False
    assert is_lat_lon_pair("200,300") is False


# --------------------------------------------------------------------------- #
# database/redis_client.py — in-memory fallback path
# --------------------------------------------------------------------------- #
def test_cache_client_falls_back_when_redis_unreachable():
    cache = CacheClient("redis://localhost:1/0")  # invalid port -> forces fallback
    assert cache.using_fallback is True

    cache.set("k", "v", ex=60)
    assert cache.get("k") == "v"

    cache.set_json("obj", {"a": 1})
    assert cache.get_json("obj") == {"a": 1}

    cache.delete("k")
    assert cache.get("k") is None


# --------------------------------------------------------------------------- #
# services/maps_service.py — no API key configured
# --------------------------------------------------------------------------- #
def test_maps_service_without_api_key_returns_fallback_links():
    service = MapsService()
    service.api_key = ""  # force the no-key branch regardless of .env
    links = service.get_map_links("Testville", 12.34, 56.78)
    assert links["provider"] == "openstreetmap_fallback"
    assert links["static_map_url"] is None
    assert "openstreetmap.org" in links["fallback_view_url"]


def test_maps_service_geocode_without_api_key_returns_none():
    service = MapsService()
    service.api_key = ""
    assert service.geocode("1600 Amphitheatre Parkway") is None


# --------------------------------------------------------------------------- #
# services/weather_service.py — error paths without a real API key
# --------------------------------------------------------------------------- #
def test_weather_service_raises_external_api_error_without_key():
    service = WeatherService(CacheClient("redis://localhost:1/0"))
    service.api_key = ""
    with pytest.raises(ExternalAPIError):
        service.get_current_weather("London")


def test_weather_service_rejects_empty_location():
    service = WeatherService(CacheClient("redis://localhost:1/0"))
    with pytest.raises(ValidationError):
        service.get_current_weather("   ")


# --------------------------------------------------------------------------- #
# services/ai_assistant_service.py — rule-based fallback paths
# --------------------------------------------------------------------------- #
class _StubForecastDay:
    def __init__(self, date_, condition, avg_temp_c, chance_of_rain, uv_index, min_temp_c=15.0, max_temp_c=30.0):
        self.date = date_
        self.condition = condition
        self.avg_temp_c = avg_temp_c
        self.chance_of_rain = chance_of_rain
        self.uv_index = uv_index
        self.min_temp_c = min_temp_c
        self.max_temp_c = max_temp_c


class _StubForecast:
    def __init__(self, days):
        self.forecast_days = days


def test_ai_assistant_rule_based_umbrella_yes():
    service = AIAssistantService(weather_service=None)
    forecast = _StubForecast([_StubForecastDay("2025-01-01", "Heavy rain", 18.0, 80, 2.0)])
    answer = service._rule_based_fallback(forecast, "Should I carry an umbrella?")
    assert "umbrella" in answer.lower()
    assert "80%" in answer


def test_ai_assistant_rule_based_umbrella_no():
    service = AIAssistantService(weather_service=None)
    forecast = _StubForecast([_StubForecastDay("2025-01-01", "Sunny", 25.0, 5, 6.0)])
    answer = service._rule_based_fallback(forecast, "Should I bring an umbrella today?")
    assert "won't need" in answer.lower() or "umbrella" in answer.lower()


def test_ai_assistant_rule_based_cricket_question():
    service = AIAssistantService(weather_service=None)
    forecast = _StubForecast(
        [
            _StubForecastDay("2025-01-01", "Rain", 20.0, 90, 2.0),
            _StubForecastDay("2025-01-02", "Sunny", 24.0, 5, 6.0),
        ]
    )
    answer = service._rule_based_fallback(forecast, "Is tomorrow good for cricket?")
    assert "2025-01-02" in answer


def test_ai_assistant_rule_based_best_day_question():
    service = AIAssistantService(weather_service=None)
    forecast = _StubForecast(
        [
            _StubForecastDay("2025-01-01", "Cloudy", 22.0, 30, 4.0),
            _StubForecastDay("2025-01-02", "Sunny", 24.0, 5, 6.0),
        ]
    )
    answer = service._rule_based_fallback(forecast, "What's the best day this week?")
    assert "2025-01-02" in answer


def test_ai_assistant_rule_based_generic_question():
    service = AIAssistantService(weather_service=None)
    forecast = _StubForecast([_StubForecastDay("2025-01-01", "Clear", 22.0, 10, 5.0)])
    answer = service._rule_based_fallback(forecast, "What's the weather vibe today?")
    assert "Clear" in answer


def test_ai_assistant_rule_based_no_forecast_days():
    service = AIAssistantService(weather_service=None)
    forecast = _StubForecast([])
    answer = service._rule_based_fallback(forecast, "Should I carry an umbrella?")
    assert "don't have forecast data" in answer.lower()
