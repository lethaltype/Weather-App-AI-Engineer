"""tests/test_weather.py — current weather, forecast, AQI, maps endpoints."""


def test_get_current_weather(client):
    response = client.get("/api/v1/weather", params={"location": "London"})
    assert response.status_code == 200
    data = response.json()
    assert data["location"]["resolved_name"] == "Testville"
    assert data["temperature_c"] == 25.0


def test_get_forecast_default_5_days(client):
    response = client.get("/api/v1/forecast", params={"location": "Paris"})
    assert response.status_code == 200
    data = response.json()
    assert len(data["forecast_days"]) == 5


def test_get_forecast_custom_days(client):
    response = client.get("/api/v1/forecast", params={"location": "Paris", "days": 3})
    assert response.status_code == 200
    assert len(response.json()["forecast_days"]) == 3


def test_get_forecast_days_out_of_range_returns_422(client):
    response = client.get("/api/v1/forecast", params={"location": "Paris", "days": 99})
    assert response.status_code == 422


def test_get_air_quality(client):
    response = client.get("/api/v1/air-quality", params={"location": "Berlin"})
    assert response.status_code == 200
    assert response.json()["us_epa_index"] == 2


def test_get_location_map(client):
    response = client.get("/api/v1/location/map", params={"location": "Tokyo"})
    assert response.status_code == 200
    data = response.json()
    assert "view_url" in data


def test_weather_missing_location_param_returns_422(client):
    response = client.get("/api/v1/weather")
    assert response.status_code == 422
