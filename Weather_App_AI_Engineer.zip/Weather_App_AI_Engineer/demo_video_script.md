# Demo Video Script: Weather App AI Engineer

**Duration**: 10–12 minutes  
**Audience**: PM Accelerator technical evaluation team  
**Goal**: Showcase full-stack capabilities, CRUD functionality, AI features, and production-grade code quality

---

## Scene 1: Introduction (30 seconds)

**Narration:**
> "Hello, I'm [Your Name]. This is the Weather App AI Engineer — a full-stack technical assessment built with FastAPI, React, PostgreSQL, and Redis. The application demonstrates backend API design, CRUD database operations, JWT authentication, external API integration, AI capabilities, and comprehensive testing."

**Visuals:**
- Show the GitHub repository URL
- Display the PM Accelerator logo and mission statement (from the app footer)
- Show the folder structure (`backend/`, `frontend/`, `docker-compose.yml`, tests, CI/CD)

---

## Scene 2: Application Architecture (1 minute)

**Narration:**
> "The backend is built with FastAPI and uses a layered architecture: routes call services, which call repositories to manage the database. All external APIs (weather, maps, AI) are wrapped in service classes with caching and error handling. The frontend is React with Vite, using React Query for server state management and a custom AuthContext for JWT tokens."

**Visuals:**
- Show the backend folder structure (api/v1/, core/, database/, models/, services/, repositories/)
- Show the frontend structure (components/, pages/, api/, context/)
- Show docker-compose.yml showing PostgreSQL, Redis, FastAPI, React services
- Show the `.github/workflows/ci.yml` file (GitHub Actions)

---

## Scene 3: User Registration & Login (1.5 minutes)

**Narration:**
> "Let's start by creating a user account. I'll navigate to the frontend at localhost:5173."

**Actions:**
1. Show the login page with "Register" link
2. Click "Register"
3. Enter email: `test@example.com`
4. Enter password: `SecurePass123` (meets validation: digits + letters)
5. Full name: `Demo User`
6. Click "Register"
7. **Verify**: User is logged in, JWT token stored in localStorage
8. Show the dashboard with greeting: "Welcome, Demo User"
9. Show the logout button in header

**API Calls Visible**:
- `POST /api/v1/auth/register` → 201 Created
- Response includes `access_token` and user details

---

## Scene 4: Weather Search (Current Weather + Forecast) (2 minutes)

**Narration:**
> "Now let's search for weather. I'll enter a location and see current conditions and a 5-day forecast."

**Actions:**
1. Find the weather search input field
2. Type `London`
3. Submit
4. **Current Weather Card Shows**:
   - Temperature: 25°C (feels like 26°C)
   - Condition: Sunny
   - Humidity: 50%
   - Wind: 10 kph
   - UV Index: 6.0
   - Weather icon
5. **5-Day Forecast Shows Below**:
   - 5 cards, each with date, high/low temp, condition, rain chance, UV
   - Use Recharts to show a line chart of temperatures

**API Calls Visible**:
- `GET /api/v1/weather?location=London` → current weather (cached)
- `GET /api/v1/forecast?location=London&days=5` → 5-day forecast

**Narration (continued)**:
> "The forecast includes temperature trends, rain probability, and UV index. The data is cached in Redis so repeated requests are instant."

---

## Scene 5: Air Quality Dashboard (30 seconds)

**Narration:**
> "The app also provides air quality data. Let's see the AQI breakdown."

**Actions:**
1. Click "Air Quality" tab or button
2. Show AQI card with:
   - CO, O3, NO2, SO2, PM2.5, PM10 levels
   - US EPA Index: 2 (Good)
   - Visual indicator (color-coded)

**API Call**:
- `GET /api/v1/air-quality?location=London`

---

## Scene 6: AI Weather Assistant (1.5 minutes)

**Narration:**
> "One of the flagship features is the AI Weather Assistant. It answers natural-language questions about weather using live forecast context. Let me ask a few example questions."

**Actions:**
1. Navigate to "Ask Assistant" section
2. **Question 1**: "Should I carry an umbrella?"
   - Assistant answer: "Yes, there's a 30% chance of rain today..."
   - Show the response is contextualized to the current forecast
3. **Question 2**: "Is tomorrow good for cricket?"
   - Assistant answer: "Tomorrow (Day 2) looks promising — sunny, 26°C, only 5% chance of rain..."
4. **Question 3**: "Best day for outdoor activities?"
   - Assistant answer: "Day 3 is the best choice — clear skies, 24°C, minimal rain risk, high UV..."

**API Call**:
- `POST /api/v1/assistant/ask` with `{"location": "London", "question": "Should I carry an umbrella?"}`

**Narration (continued)**:
> "The assistant combines live weather data with OpenAI's API (or falls back to rule-based logic if no API key is configured). This demonstrates AI integration in a real-world scenario."

---

## Scene 7: Create & Store Weather Query (CRUD: Create) (1.5 minutes)

**Narration:**
> "The app supports full CRUD operations for stored weather queries. Let me create a new query to plan a trip."

**Actions:**
1. Click "Create New Query" or "Save This Search"
2. Form appears with:
   - Location: `Paris` (pre-filled from previous search)
   - Start Date: `2025-01-15`
   - End Date: `2025-01-20`
   - Notes: `Planning a week-long trip`
3. Click "Save"
4. **Response shows**:
   - Query saved with ID (e.g., #42)
   - Resolved location: Paris, France
   - Latitude/Longitude: 48.856, 2.295
   - Temperature summary: Avg 5.2°C, Min 2.1°C, Max 8.4°C
   - Condition: Mostly Cloudy
5. Display toast: "Query saved successfully!"

**API Call**:
- `POST /api/v1/query` with location + date range
- Returns WeatherQueryOut schema with auto-populated geocoding + temperature stats

---

## Scene 8: List & Update Queries (CRUD: Read + Update) (1 minute)

**Narration:**
> "Now let's view our stored queries and update one."

**Actions:**
1. Click "My Queries" or "Query History"
2. **List appears**:
   - Shows 2 queries: London (from earlier) and Paris (just created)
   - Each row: Location, Country, Date Range, Avg Temp, Condition
   - Pagination info: "Showing 1–2 of 2"
3. Click "Edit" on the London query
4. **Update Form**:
   - Notes field: change from empty to `"Business meeting + sightseeing"`
   - Click "Save Changes"
5. **Confirmation**: Toast shows "Query updated successfully!"
6. **List refreshes** with updated notes visible

**API Calls**:
- `GET /api/v1/queries` → paginated list
- `PUT /api/v1/query/1` with updated notes → 200 OK

---

## Scene 9: Delete Query (CRUD: Delete) (30 seconds)

**Narration:**
> "Let me delete the Paris query to demonstrate the DELETE operation."

**Actions:**
1. Click "Delete" button on the Paris query
2. Confirmation modal: "Are you sure? This action cannot be undone."
3. Click "Confirm Delete"
4. **Query disappears from list**
5. Toast: "Query deleted successfully!"
6. List now shows only 1 query (London)

**API Call**:
- `DELETE /api/v1/query/2` → 204 No Content

---

## Scene 10: Data Export (CSV & JSON) (1 minute)

**Narration:**
> "Users can export their stored queries as CSV or JSON for further analysis or integration with other tools."

**Actions:**
1. Click "Export" menu
2. **Option 1: Download as CSV**
   - File `weather_queries.csv` is downloaded
   - Open in text editor or spreadsheet
   - Show columns: id, location_query, resolved_name, country, start_date, end_date, avg_temperature_c, condition_summary, notes, created_at
   - Show the London query row
3. **Back to browser, click Export again**
4. **Option 2: Download as JSON**
   - File `weather_queries.json` is downloaded
   - Show in text editor (pretty-printed JSON with full structure)

**API Calls**:
- `GET /api/v1/export/csv` → StreamingResponse with text/csv
- `GET /api/v1/export/json` → StreamingResponse with application/json

---

## Scene 11: Backend Tests & Code Quality (1.5 minutes)

**Narration:**
> "Let's verify the quality of the code with the test suite. The backend has 54 comprehensive tests covering authentication, APIs, CRUD, export, and AI assistant."

**Actions:**
1. Open terminal in `backend/` directory
2. Run: `pytest tests/ --cov=app --cov-report=term-missing`
3. **Output shows**:
   ```
   ============================== 54 passed in 4.35s ==============================
   
   coverage: platform linux, python 3.12.3-final-0
   Name                                     Stmts   Miss  Cover
   ...
   TOTAL                                      845    118    86%
   ```
4. Show individual test names passing:
   - `test_register_creates_user_and_returns_token PASSED`
   - `test_login_with_correct_credentials_succeeds PASSED`
   - `test_create_query_authenticated_attaches_user PASSED`
   - `test_export_csv_contains_created_record PASSED`
   - `test_ai_assistant_rule_based_umbrella_yes PASSED`
   - ... (others)

**Narration (continued)**:
> "86% code coverage exceeds the 80% target. All critical paths are tested, including error handling, validation, authentication, and the AI assistant's fallback logic."

---

## Scene 12: API Documentation (30 seconds)

**Narration:**
> "FastAPI auto-generates interactive API documentation at `/docs`. Let me show the available endpoints."

**Actions:**
1. Navigate to `http://localhost:8000/docs`
2. Show Swagger UI with all endpoints grouped by tags:
   - Authentication
   - Weather
   - Weather Queries (CRUD)
   - Export
   - AI Assistant
   - Health
3. Click on one endpoint (e.g., `POST /api/v1/query`)
4. Show:
   - Request schema (WeatherQueryCreate)
   - Response schema (WeatherQueryOut)
   - Example values
   - Try it out functionality

---

## Scene 13: Docker Deployment (1 minute)

**Narration:**
> "The entire application is containerized with Docker. Running docker-compose spins up PostgreSQL, Redis, FastAPI backend, and React frontend."

**Actions:**
1. Show `docker-compose.yml` file
2. Run: `docker-compose up`
3. Show console output:
   ```
   postgres_1  | ...listening on IPv4 address...
   redis_1     | ...Ready to accept connections...
   backend_1   | ...Uvicorn running on 0.0.0.0:8000...
   frontend_1  | ...Vite dev server listening...
   ```
4. After ~30 seconds, show:
   - Frontend at http://localhost:5173 (live, hot-reloading)
   - Backend API at http://localhost:8000
   - Health check: `GET /api/v1/health` returns `{"status": "ok", "database": "ok", "cache": "redis"}`

---

## Scene 14: CI/CD (GitHub Actions) (30 seconds)

**Narration:**
> "The project includes a GitHub Actions CI/CD pipeline that runs tests and linting on every push and pull request."

**Actions:**
1. Show `.github/workflows/ci.yml` file
2. Show a successful run on GitHub (Actions tab)
3. Show:
   - Backend job: `pytest tests/` ✅
   - Backend job: `flake8 app tests` ✅
   - Frontend job: `npm build` ✅
   - Coverage report uploaded to Codecov
4. Highlight that CI/CD ensures code quality before merge

---

## Scene 15: About PM Accelerator (15 seconds)

**Narration:**
> "This project was built for PM Accelerator's technical assessment. PM Accelerator's mission is to enable PM professionals and entry-level individuals to break through into Product Management through hands-on, real-world experience, mentorship, and community-driven learning."

**Visuals:**
- Show the footer of the app with PM Accelerator info
- Show the mission statement from the README
- Link to PM Accelerator on LinkedIn

---

## Conclusion (30 seconds)

**Narration:**
> "This Weather App demonstrates a complete, production-grade full-stack application with:
> - Robust backend (FastAPI, PostgreSQL, Redis, JWT)
> - Responsive frontend (React, charts, forms)
> - Full CRUD database operations
> - External API integration (WeatherAPI, Google Maps, OpenAI)
> - AI capabilities (natural-language Q&A)
> - Comprehensive testing (86% coverage)
> - Docker containerization
> - CI/CD pipeline
> 
> All code is clean, well-tested, documented, and ready for production. Thank you."

**Visuals:**
- Show GitHub repo URL
- Show the application running smoothly
- Fade out with PM Accelerator logo

---

## Technical Notes for Recording

- **Audio**: Clear voice, moderate pace, avoid jargon where possible
- **Screen Resolution**: 1920×1080 or higher for readability
- **Browser**: Use Chrome DevTools (F12) to show network requests/console if needed
- **Timing**: Aim for 10–12 minutes total
- **Edits**: Use screen recording software (OBS, Loom, ScreenFlow) to:
  - Add intro/outro with your name and PM Accelerator branding
  - Highlight key sections (draw attention to code, test results)
  - Pause on important points (API responses, test coverage)
  - Speed up mundane steps (file editing, terminal scrolling)
- **Hosting**: Upload to YouTube, Google Drive, or Vimeo and include the link in your submission

