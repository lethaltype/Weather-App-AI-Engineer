import React, { useState, useEffect } from 'react'
import { QueryClient, QueryClientProvider } from 'react-query'
import { AuthContext } from './context/AuthContext'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import './styles/App.css'

const queryClient = new QueryClient()

function App() {
  const [token, setToken] = useState(localStorage.getItem('token') || null)
  const [user, setUser] = useState(() => {
    const stored = localStorage.getItem('user')
    return stored ? JSON.parse(stored) : null
  })

  const handleLogin = (newToken, userData) => {
    setToken(newToken)
    setUser(userData)
    localStorage.setItem('token', newToken)
    localStorage.setItem('user', JSON.stringify(userData))
  }

  const handleLogout = () => {
    setToken(null)
    setUser(null)
    localStorage.removeItem('token')
    localStorage.removeItem('user')
  }

  return (
    <QueryClientProvider client={queryClient}>
      <AuthContext.Provider value={{ token, user, handleLogin, handleLogout }}>
        <div className="app">
          <header className="header">
            <div>
              <h1>🌍 Weather App AI Engineer</h1>
            </div>
            {token && (
              <div className="header-right">
                <div className="user-info">
                  Welcome, <strong>{user?.full_name || user?.email}</strong>
                </div>
                <button onClick={handleLogout} className="logout-btn">
                  Logout
                </button>
              </div>
            )}
          </header>
          <main>
            {token ? <Dashboard /> : <Login onLogin={handleLogin} />}
          </main>
          <footer style={{ textAlign: 'center', padding: '1rem', color: 'white', fontSize: '0.85rem' }}>
            <p>🎓 Built for <strong>PM Accelerator</strong> — Breaking into Product Management</p>
          </footer>
        </div>
      </AuthContext.Provider>
    </QueryClientProvider>
  )
}

export default App
