import React, { useState } from 'react'
import client from '../api/client'
import '../styles/Dashboard.css'

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState('weather')
  const [location, setLocation] = useState('')
  const [weather, setWeather] = useState(null)
  const [forecast, setForecast] = useState(null)
  const [aqi, setAqi] = useState(null)
  const [queries, setQueries] = useState([])
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [queryNotes, setQueryNotes] = useState('')

  const searchWeather = async () => {
    if (!location.trim()) {
      setError('Please enter a location')
      return
    }
    
    setError('')
    setLoading(true)
    
    try {
      const [weatherRes, forecastRes, aqiRes] = await Promise.all([
        client.get(`/weather?location=${location}`),
        client.get(`/forecast?location=${location}&days=5`),
        client.get(`/air-quality?location=${location}`),
      ])
      
      setWeather(weatherRes.data)
      setForecast(forecastRes.data)
      setAqi(aqiRes.data)
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to fetch weather data')
    } finally {
      setLoading(false)
    }
  }

  const saveQuery = async () => {
    if (!location.trim()) {
      setError('Please search for a location first')
      return
    }

    setLoading(true)
    try {
      await client.post('/query', {
        location_query: location,
        notes: queryNotes,
      })
      setQueryNotes('')
      alert('Query saved successfully!')
      await loadQueries()
    } catch (err) {
      setError('Failed to save query')
    } finally {
      setLoading(false)
    }
  }

  const loadQueries = async () => {
    try {
      const res = await client.get('/queries?page=1&page_size=10')
      setQueries(res.data.items || [])
    } catch (err) {
      setError('Failed to load queries')
    }
  }

  const deleteQuery = async (id) => {
    if (confirm('Delete this query?')) {
      try {
        await client.delete(`/query/${id}`)
        await loadQueries()
      } catch (err) {
        setError('Failed to delete query')
      }
    }
  }

  React.useEffect(() => {
    if (activeTab === 'history') {
      loadQueries()
    }
  }, [activeTab])

  return (
    <div className="dashboard">
      <div className="tabs">
        <button
          className={`tab ${activeTab === 'weather' ? 'active' : ''}`}
          onClick={() => setActiveTab('weather')}
        >
          🌤️ Weather
        </button>
        <button
          className={`tab ${activeTab === 'forecast' ? 'active' : ''}`}
          onClick={() => setActiveTab('forecast')}
        >
          📊 Forecast
        </button>
        <button
          className={`tab ${activeTab === 'aqi' ? 'active' : ''}`}
          onClick={() => setActiveTab('aqi')}
        >
          💨 Air Quality
        </button>
        <button
          className={`tab ${activeTab === 'history' ? 'active' : ''}`}
          onClick={() => setActiveTab('history')}
        >
          📝 History
        </button>
      </div>

      {error && <div className="error-banner">{error}</div>}

      <div className="search-section">
        <input
          type="text"
          placeholder="Enter city name, zip code, or coordinates (lat,lon)"
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && searchWeather()}
        />
        <button onClick={searchWeather} disabled={loading}>
          {loading ? 'Searching...' : '🔍 Search'}
        </button>
      </div>

      {activeTab === 'weather' && (
        <div className="content">
          {weather ? (
            <div className="weather-card">
              <h2>{weather.location}</h2>
              <div className="weather-main">
                <div className="temp">{weather.temperature}°C</div>
                <div className="condition">{weather.condition}</div>
              </div>
              <div className="weather-details">
                <div>Feels like: {weather.feels_like}°C</div>
                <div>Humidity: {weather.humidity}%</div>
                <div>Wind: {weather.wind_speed} kph</div>
                <div>UV Index: {weather.uv_index}</div>
              </div>
              
              <div className="save-section">
                <textarea
                  placeholder="Add notes for this query (optional)"
                  value={queryNotes}
                  onChange={(e) => setQueryNotes(e.target.value)}
                />
                <button onClick={saveQuery}>💾 Save Query</button>
              </div>
            </div>
          ) : (
            <div className="placeholder">
              Enter a location above to see current weather
            </div>
          )}
        </div>
      )}

      {activeTab === 'forecast' && (
        <div className="content">
          {forecast ? (
            <div className="forecast-grid">
              {forecast.forecast?.map((day, idx) => (
                <div key={idx} className="forecast-card">
                  <div className="date">{day.date}</div>
                  <div className="temps">
                    <span className="high">High: {day.max_temp}°</span>
                    <span className="low">Low: {day.min_temp}°</span>
                  </div>
                  <div className="condition">{day.condition}</div>
                  <div className="details">
                    <div>Rain: {day.rain_chance}%</div>
                    <div>UV: {day.uv_index}</div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="placeholder">
              Search for a location to see 5-day forecast
            </div>
          )}
        </div>
      )}

      {activeTab === 'aqi' && (
        <div className="content">
          {aqi ? (
            <div className="aqi-card">
              <h3>Air Quality Index</h3>
              <div className="aqi-main">
                <div className="aqi-index">{aqi.us_epa_index}</div>
                <div className="aqi-label">{aqi.us_epa_index === 1 ? 'Good' : aqi.us_epa_index === 2 ? 'Moderate' : 'Poor'}</div>
              </div>
              <div className="aqi-details">
                <div>CO: {aqi.co}</div>
                <div>O₃: {aqi.o3}</div>
                <div>NO₂: {aqi.no2}</div>
                <div>SO₂: {aqi.so2}</div>
                <div>PM2.5: {aqi.pm2_5}</div>
                <div>PM10: {aqi.pm10}</div>
              </div>
            </div>
          ) : (
            <div className="placeholder">
              Search for a location to see air quality data
            </div>
          )}
        </div>
      )}

      {activeTab === 'history' && (
        <div className="content">
          {queries.length > 0 ? (
            <div className="queries-list">
              {queries.map((q) => (
                <div key={q.id} className="query-item">
                  <div className="query-header">
                    <h4>{q.resolved_name}, {q.country}</h4>
                    <button 
                      className="delete-btn"
                      onClick={() => deleteQuery(q.id)}
                    >
                      🗑️ Delete
                    </button>
                  </div>
                  <div className="query-body">
                    <div>📍 {q.latitude.toFixed(2)}, {q.longitude.toFixed(2)}</div>
                    <div>📅 {q.start_date} to {q.end_date}</div>
                    <div>🌡️ Avg: {q.avg_temperature_c}°C (Min: {q.min_temperature_c}°C, Max: {q.max_temperature_c}°C)</div>
                    {q.notes && <div>📝 {q.notes}</div>}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="placeholder">
              No saved queries yet. Save a search above!
            </div>
          )}
        </div>
      )}
    </div>
  )
}
