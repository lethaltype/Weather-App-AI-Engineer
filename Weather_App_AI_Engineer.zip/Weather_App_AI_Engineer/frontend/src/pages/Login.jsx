import React, { useState } from 'react'
import client from '../api/client'
import '../styles/Login.css'

export default function Login({ onLogin }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [fullName, setFullName] = useState('')
  const [isRegister, setIsRegister] = useState(false)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      if (isRegister) {
        const res = await client.post('/auth/register', {
          email,
          password,
          full_name: fullName,
        })
        setEmail('')
        setPassword('')
        setFullName('')
        setIsRegister(false)
        setError('')
        alert('Registration successful! Please log in.')
      } else {
        const res = await client.post('/auth/login', { email, password })
        onLogin(res.data.access_token, res.data.user)
      }
    } catch (err) {
      const msg = err.response?.data?.detail || err.message || 'Error occurred'
      setError(msg)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="login-container">
      <div className="login-card">
        <h2>{isRegister ? '📝 Register' : '🔐 Login'}</h2>
        
        {error && <div className="error-message">{error}</div>}
        
        <form onSubmit={handleSubmit}>
          {isRegister && (
            <div className="form-group">
              <label>Full Name</label>
              <input
                type="text"
                placeholder="Your name"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                required
              />
            </div>
          )}
          
          <div className="form-group">
            <label>Email</label>
            <input
              type="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          
          <div className="form-group">
            <label>Password</label>
            <input
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          
          <button type="submit" disabled={loading} className="submit-btn">
            {loading ? 'Loading...' : isRegister ? 'Create Account' : 'Sign In'}
          </button>
        </form>
        
        <div className="toggle-auth">
          <p>{isRegister ? 'Already have an account?' : "Don't have an account?"}</p>
          <button
            type="button"
            onClick={() => {
              setIsRegister(!isRegister)
              setError('')
              setEmail('')
              setPassword('')
              setFullName('')
            }}
            className="toggle-btn"
          >
            {isRegister ? 'Sign In' : 'Create Account'}
          </button>
        </div>
        
        <div className="demo-info">
          <p>🎓 <strong>PM Accelerator</strong></p>
          <p style={{fontSize: '0.85rem', marginTop: '0.5rem'}}>
            Breaking into Product Management through hands-on experience
          </p>
        </div>
      </div>
    </div>
  )
}
