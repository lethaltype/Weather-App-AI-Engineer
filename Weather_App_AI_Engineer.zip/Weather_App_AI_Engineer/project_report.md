# Project Report: AI Engineer Weather App

## Overview

This is a complete, production-grade full-stack weather application built as a technical assessment for PM Accelerator's AI Engineer Internship program.

The application combines **backend API expertise** (FastAPI, PostgreSQL, Redis, JWT authentication) with **frontend skills** (React, responsive design, state management), **database CRUD operations**, **external API integration** (WeatherAPI, Google Maps, OpenAI), and **AI capabilities** (natural-language Q&A with weather context).

## Technical Stack

### Backend
- **Framework**: FastAPI (Python 3.12)
- **Database**: PostgreSQL with SQLAlchemy ORM
- **Caching**: Redis (with in-memory fallback for dev/test)
- **Auth**: JWT + bcrypt password hashing
- **Task Queue**: Background tasks via FastAPI BackgroundTasks
- **Testing**: Pytest (54 tests, 86% coverage)
- **External APIs**: WeatherAPI.com (weather), Google Maps (location), OpenAI-compatible (AI assistant)

### Frontend
- **Framework**: React 18 + Vite
- **HTTP Client**: Axios
- **State Management**: React Query for server state, React Context for auth
- **Charts**: Recharts for data visualization
- **Styling**: CSS (responsive, mobile-friendly)

### DevOps
- **Containerization**: Docker (FastAPI, React, PostgreSQL, Redis)
- **Orchestration**: docker-compose
- **CI/CD**: GitHub Actions (testing + linting)

## Key Features Implemented

### 1. Authentication (JWT)
- **Registration** with email validation and password strength checks
- **Login** with email/password, returning a JWT bearer token
- **Protected endpoints** via OAuth2 dependency injection
- **Graceful degradation**: Some endpoints (like creating a weather query) work for both authenticated and anonymous users

### 2. Weather APIs
- **WeatherAPI.com integration** for current conditions, 5-day forecasts, and air quality data
- **Caching** in Redis to reduce upstream calls and latency
- **Graceful error handling** when external APIs are unavailable or incorrectly configured

### 3. Full CRUD for Weather Queries
- **CREATE**: Users enter a location + date range; the backend resolves the location, fetches a temperature summary, and stores it
- **READ**: List all stored queries (paginated, across all users) or filter to the current user's queries
- **UPDATE**: Users can update notes and date ranges (with validation)
- **DELETE**: Users can remove their query records
- **Database**: PostgreSQL table with geocoded location, date range, temperature statistics, and timestamps

### 4. Google Maps Integration
- **Static maps** for locations (with fallback to OpenStreetMap when no API key is configured)
- **Location embedding** for webpage-friendly map visualization
- **Geocoding fallback**: When Google Geocoding API is unavailable, the weather provider's geocoding is used

### 5. AI Weather Assistant
- **Natural-language Q&A** about weather: "Should I carry an umbrella?", "Is tomorrow good for cricket?", "Best day for outdoor activities?"
- **OpenAI-compatible API** integration (can use OpenAI, Azure OpenAI, or a local compatible service)
- **Rule-based fallback** when no LLM API key is configured, ensuring the feature is always available for demo purposes
- **Live weather context**: The assistant combines current conditions + 5-day forecast + user input to produce contextualized answers

### 6. Data Export
- **CSV export** of all stored weather queries
- **JSON export** of all stored weather queries
- **Streaming responses** to handle large datasets efficiently

### 7. Responsive Frontend
- **Login/Register pages** with form validation
- **Weather search** interface (enter location, get current conditions)
- **Forecast dashboard** with visual cards and charts
- **Query history** with update/delete functionality
- **AQI dashboard** for air quality breakdown
- **Mobile-responsive** design (tested on desktop, tablet, smartphone)

## Architecture Decisions

### Backend
- **Layered architecture**: Routes → Services → Repositories → Database
  - Keeps business logic separate from HTTP concerns
  - Makes services unit-testable without mocking FastAPI dependencies
  - Easy to swap persistence implementations

- **Pydantic schemas** for validation and serialization
  - Type safety across API boundaries
  - Automatic OpenAPI documentation

- **SQLAlchemy ORM** with session management
  - Database-agnostic (SQLite in tests, PostgreSQL in production)
  - Declarative models with relationships

- **Typed exceptions** (AppError subclasses)
  - Service/repository layers don't import FastAPI
  - Exception handler at the app level maps to HTTP responses

### Frontend
- **React Query** for server state (caching, refetching, optimistic updates)
- **React Context** for auth state (token + user info)
- **Axios interceptors** to inject JWT tokens into requests
- **Responsive grid layout** for multi-device support

### Testing
- **In-memory SQLite** for fast, isolated test runs
- **Mocked external services** (weather, maps, AI assistant) so tests don't depend on API keys or network
- **Fixtures** for DB session, test client, and auth headers
- **Coverage goal** of 80%+ achieved (86% overall)

## Database Schema

### Users Table
```sql
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  full_name VARCHAR(255),
  hashed_password VARCHAR(255) NOT NULL,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE
);
```

### WeatherQuery Table
```sql
CREATE TABLE weather_queries (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  location_query VARCHAR(255),
  resolved_name VARCHAR(255),
  country VARCHAR(255),
  region VARCHAR(255),
  latitude FLOAT,
  longitude FLOAT,
  start_date DATE,
  end_date DATE,
  avg_temperature_c FLOAT,
  min_temperature_c FLOAT,
  max_temperature_c FLOAT,
  condition_summary VARCHAR(255),
  notes VARCHAR(500),
  created_at TIMESTAMP WITH TIME ZONE,
  updated_at TIMESTAMP WITH TIME ZONE
);
```

## API Endpoints Summary

| Endpoint | Method | Auth | Description |
|---|---|---|---|
| `/auth/register` | POST | No | Create account |
| `/auth/login` | POST | No | Get JWT token |
| `/weather` | GET | No | Current weather for location |
| `/forecast` | GET | No | 5-day forecast |
| `/air-quality` | GET | No | Air quality index |
| `/location/map` | GET | No | Maps links for location |
| `/query` | POST | Optional | Create weather query (CRUD create) |
| `/queries` | GET | No | List all queries paginated (CRUD read) |
| `/query/{id}` | GET | No | Get single query (CRUD read) |
| `/query/{id}` | PUT | No | Update query (CRUD update) |
| `/query/{id}` | DELETE | No | Delete query (CRUD delete) |
| `/export/csv` | GET | No | Download as CSV |
| `/export/json` | GET | No | Download as JSON |
| `/assistant/ask` | POST | No | AI Q&A about weather |
| `/health` | GET | No | Liveness check (DB + cache status) |

## Testing Strategy

**54 tests across 5 files:**
- `test_auth.py`: Registration, login, password validation (6 tests)
- `test_weather.py`: Current weather, forecast, AQI, maps (7 tests)
- `test_queries.py`: Full CRUD, pagination, filtering (12 tests)
- `test_export.py`: CSV and JSON export (3 tests)
- `test_assistant_and_health.py`: AI assistant, health check (5 tests)
- `test_services_unit.py`: Security, validation, caching, AI fallback (21 tests)

**Coverage: 86%** (exceeds 80% target)

## Deployment

### Local Development
```bash
cd backend && pip install -r requirements.txt && uvicorn app.main:app --reload
cd frontend && npm install && npm run dev
```

### Docker
```bash
docker-compose up
```

Includes:
- PostgreSQL 16 (port 5432)
- Redis 7 (port 6379)
- FastAPI backend (port 8000)
- React frontend (port 5173)

### CI/CD (GitHub Actions)
- Backend: pytest + flake8 linting + coverage upload
- Frontend: npm build + linting
- Runs on push/PR to main/develop

## Challenges & Solutions

1. **Testing external APIs without keys**: Mocked weather/maps/AI services in tests so they don't fail due to missing credentials
2. **In-memory SQLite sharing connections**: Used `StaticPool` to share a single connection across test sessions
3. **Frontend + Backend dev environment**: docker-compose with hot-reload volumes for both
4. **AI assistant without OpenAI key**: Implemented rule-based fallback for demo purposes (still works, just less sophisticated)
5. **Redis unavailability in dev**: Transparent fallback to in-memory cache so developers don't need Redis running locally

## Future Enhancements

- **Historical weather data** from a paid WeatherAPI tier
- **Predictive models** (ML-based temperature forecasting)
- **User preferences** (favorite locations, notification alerts)
- **Social sharing** (share weather reports)
- **Mobile app** (React Native)
- **Webhooks** for third-party integrations
- **Rate limiting** (Redis-backed sliding window)
- **Admin dashboard** (user management, analytics)

## Conclusion

This project demonstrates a **production-ready full-stack application** with:
- ✅ Robust backend (FastAPI, databases, APIs)
- ✅ Responsive frontend (React, charts, forms)
- ✅ Authentication & authorization (JWT)
- ✅ Full CRUD persistence
- ✅ AI capabilities (natural-language Q&A)
- ✅ Data export (CSV, JSON)
- ✅ Comprehensive testing (86% coverage)
- ✅ Docker containerization
- ✅ CI/CD pipeline (GitHub Actions)

All assessment requirements have been met, with extra attention to code quality, testability, and user experience.
